var SearchListCtrl = (function () {
    var doT = require('../lib/dot');
    var template = require("../views/searchListView.dot");
    var Promise = require("../lib/promise");
    var EventHandler = require("../events/event");
    var KEY = require("../utils/key");
    var CONFIG = require("../utils/config");
    var NavHelper = require("../helper/nav-helper");
    var Generic = require('../utils/generic');
    var Popup = require('./popup/index');
    var ApiHelper = require("../helper/api-helper");
    var Loader=require('./popup/loader');

    var that = this;
    this.init = function (data,catid) {
        that.data = data;
        that.catid = catid;
        return new Promise(function (fulfil, reject) {
            render(data, catid);
            fulfil();
        });
    };

    this.destroy = function () {
        try {
            if (document.querySelector('.search-list-container')) {
                document.querySelector('.search-list-container').innerHTML = '';
            }
        } catch (err) {
        }
    };

    function render(data, catid) {
        var container = document.querySelector(".search-list-container");
        var tempFn = doT.template(template);
        container.innerHTML = tempFn({data: data, category_id:catid});
        EventHandler.init([{
            element: ".search-list-container",
            events: [
                {eventType: "keydown", handler: KeydownHandler},
                {eventType: "click", handler: clickHandler},
                {eventType: "focus", handler: focusHandler}
            ]
        }]);
    }

    function KeydownHandler(e) {
        var key = e.keyCode ? e.keyCode : e.which;
        switch (key) {
            case KEY.LEFT:
                NavHelper.navigation(e, CONFIG.NAV_DIRECTION.HORIZONTAL);
                break;
            case KEY.RIGHT:
                NavHelper.navigation(e, CONFIG.NAV_DIRECTION.HORIZONTAL);
                break;
            case KEY.ENTER:
                clickHandler(e);
                break;
            case KEY.BACK:
                var activeElement=document.activeElement;
                Popup.show(CONFIG.POPUP_TYPE.EXIT,function () {
                    activeElement.focus();
                });
                break;
            case KEY.UP:
                if (document.querySelector('#four'))
                    document.querySelector('#four').focus();
                break;
        }
    }

    function clickHandler(e) {
        if (Generic.getNetworkStatus()) {
            var userDetails = localStorage.getItem('userDetails');
            userDetails = userDetails && JSON.parse(userDetails);
            if (userDetails && userDetails.email) {
                var c = e.target.getAttribute('col');
                var catid = e.target.getAttribute('catid');
                if (c) {
                    CONFIG.playerData = that.data[c];
                    CONFIG.playerData.catid = catid;
                    Loader.show();
                    ApiHelper.getChannelData(CONFIG.playerData)
                        .then(function (response) {
                            if (response.data) {
                                CONFIG.channelDetails = response.data;
                            }
                            Loader.hide();
                            window.changeUrl('player');
                        }, function (error) {

                        });
                }
            }else{
                document.querySelector('.home-container').style.background='#000';
                CONFIG.selectedMenu='login';
                window.changeUrl('login');
            }
        }
        else {
            var activeElement = document.activeElement;
            Popup.show(CONFIG.POPUP_TYPE.NETWORK, function () {
                activeElement.focus();
            });
        }
    }

    function focusHandler(e) {
        var scrollclass = e.target.parentNode.getAttribute('scrollclass');
        var c = e.target.getAttribute('col');
        NavHelper.scrollH(c, 3.5, scrollclass, 1);
    }

});

module.exports = new SearchListCtrl();
