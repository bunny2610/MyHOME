var SplashCtrl = function () {
  var doT = require("../lib/dot");
  var template = require("../views/splash.dot");
  var Generic = require("../utils/generic");
  var Player = require("../utils/player");

  this.init = function () {
    render();
  };

  this.destroy = function () {
    try {
      var bannerContainer = document.querySelector(".banner-container");
      var homeContent = document.querySelector(".home-content");
      if (bannerContainer) bannerContainer.innerHTML = "";
      if (homeContent) homeContent.innerHTML = "";
    } catch (err) {}
  };

  function render() {
    var container = document.getElementById("AppContainer");
    var tempFn = doT.template(template);
    container.innerHTML = tempFn({});
    container.innerHTML = tempFn({ platform: Generic.getDeviceOS() });
    setTimeout(function () {
      initPlayer();
    }, 100);
  }

  function initPlayer() {
    var path = "../splashs.mp4";
    Player.init(path, playerCallback);
  }

  function playerCallback(type, data, data1) {
    console.log(type, data, data1);
  }
};

module.exports = new SplashCtrl();
