const { colors } = require("gulp-util");

var LoginCtrl = function () {
  var doT = require("../lib/dot");
  var template = require("../views/loginView.dot");
  var Promise = require("../lib/promise");
  var CONFIG = require("../utils/config");
  var Loader = require("./popup/loader");
  var ApiHeper = require("../helper/api-helper");

  CONFIG.polltimeout = null;
  
  this.init = function () {
    Loader.show();
    return new Promise(function (fulfil, reject) {
      ApiHeper.generateOtp().then(
        function (response) {
          if (response.data) {
            CONFIG.OTP = response.data.otp;
            render(response.data);
          } else {
            render();
          }
          fulfil();
        },
        function (error) {
          render(error);
          fulfil();
        }
      );
    });
  };

  this.destroy = function () {
    try {} catch (err) {}
  };

  function render(data) {
    var container = document.querySelector(".home-content");
    document.querySelector(".preview-video-container").style.display = "none";
    document.querySelector(".home-content").style.height = "100%";
    // document.querySelector(".home-content") .style.display = "inherit";
    document.querySelector(".home-container").style.removeProperty("background");
    

    var tempFn = doT.template(template);
    container.innerHTML = tempFn({ data: data });
    Loader.hide();

    const userDetails = JSON.parse(localStorage.getItem("userDetails2"));
    if (userDetails && userDetails.email) {
      window.changeUrl("settings");
    } else {
      pooling();
    }
    if (document.querySelector(".menu-list .active")) {
      document.querySelector(".menu-list .active").classList.remove("active");
      document.querySelector("#settings").classList.add("active");
      document.querySelector("#settings").focus();
    }
    document.querySelector(".app-container").style.position = "relative";
  }

  function pooling() {
    if (CONFIG.polltimeout) {
      clearTimeout(CONFIG.polltimeout);
    }
    CONFIG.polltimeout = setTimeout(function () {
      ApiHeper.verifyOtp().then(
        function (response) {
          localStorage.setItem("userDetails2", JSON.stringify(response.data));
          if (response.data.status === "COMPLETED") {
            clearTimeout(CONFIG.polltimeout);
            CONFIG.userData = response.data;
            // CONFIG.homeData = null;
            window.changeUrl("settings");
          } else {
            pooling();
          }
        },
        function (error) {}
      );
    }, 5000);
  }
};

module.exports = new LoginCtrl();
