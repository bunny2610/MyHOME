var FavouritesCtrl = function () {
  var doT = require("../lib/dot");
  var template = require("../views/favouritesView.dot");
  var Promise = require("../lib/promise");
  var ApiHelper = require("../helper/api-helper");
  var EventHandler = require("../events/event");
  var NavHelper = require("../helper/nav-helper");
  var Loader = require("./popup/loader");
  var KEY = require("../utils/key");
  var CONFIG = require("../utils/config");
  var Generic = require("../utils/generic");
  var Popup = require("./popup/index");
  var menuCtrl = require("../controllers/menuCtrl");

  this.init = function () {
    Loader.show();
    var userDetails = localStorage.getItem("userDetails");
    userDetails = userDetails && JSON.parse(userDetails);
    if (userDetails && userDetails.email) {
      ApiHelper.getFavoritesList({
        email: userDetails.email,
        account_availability: "TRUE",
      }).then(
        function (response) {
          var data = {
            category_id: response.data.category_id,
            filter: [],
          };
          if (
            response.data &&
            response.data.channel_details &&
            response.data.channel_details.length
          ) {
            for (
              var counter = 0;
              counter < response.data.channel_details.length;
              counter = counter + 6
            ) {
              data.filter.push(
                response.data.channel_details.splice(counter, 6)
              );
            }
            render(data);
          } else {
            render();
          }
        },
        function (error) {
          render();
        }
      );
    } else {
      render();
    }
  };

  this.destroy = function () {
    try {
    } catch (err) {}
  };

  function render(data) {
    return new Promise(function (fulfil, reject) {
      var container = document.querySelector(".home-container");
      var tempFn = doT.template(template);
      container.innerHTML = tempFn({ data: data });
      EventHandler.init([
        {
          element: ".list-container",
          events: [
            { eventType: "keydown", handler: KeydownHandler },
            { eventType: "click", handler: clickHandler },
            { eventType: "focus", handler: focusHandler },
          ],
        },
      ]);
      Loader.hide();
      menuCtrl.init();
      setTimeout(function () {
        document.querySelector(".group").style.marginTop = "0em";
        if (
          CONFIG.selectedElement &&
          document.querySelector("#" + CONFIG.selectedElement)
        ) {
          document.querySelector("#" + CONFIG.selectedElement).focus();
        }
        document.querySelector(".app-container").style.position = "relative";
      }, 200);
      fulfil();
    });
  }

  function KeydownHandler(e) {
    var key = e.keyCode ? e.keyCode : e.which;
    var r, row, h;
    switch (key) {
      case KEY.LEFT:
        NavHelper.navigation(e, CONFIG.NAV_DIRECTION.HORIZONTAL);
        break;
      case KEY.RIGHT:
        NavHelper.navigation(e, CONFIG.NAV_DIRECTION.HORIZONTAL);
        break;
      case KEY.UP:
        r = e.target.getAttribute("up");
        row = e.target.getAttribute("row");
        if (document.querySelector("ul[row='" + r + "']")) {
          NavHelper.scrollVDynamic(row, 18, "#list-wrapper1", "UP");
          document.querySelector("ul[row='" + r + "'] li").focus();
        } else if (document.querySelector(".banner-container img")) {
          document.querySelector(".banner-container img").focus();
        } else if (document.querySelector(".menu-list")) {
          document.querySelector(".menu-list .active").focus();
        }
        break;
      case KEY.DOWN:
        r = e.target.getAttribute("down");
        row = e.target.getAttribute("row");
        if (document.querySelector("ul[row='" + r + "']")) {
          NavHelper.scrollVDynamic(row, 18, "#list-wrapper1", "DOWN");
          document.querySelector("ul[row='" + r + "'] li").focus();
        }
        break;
      case KEY.ENTER:
        clickHandler(e);
        break;
      case KEY.BACK:
        if (document.querySelector(".menu-list .active")) {
          document.querySelector(".menu-list .active").focus();
        } else {
          document.querySelector(".menu-item").focus();
        }
        // var activeElement = document.activeElement;
        // Popup.show(CONFIG.POPUP_TYPE.EXIT, function () {
        //     activeElement.focus();
        // });
        break;
    }
  }

  function clickHandler(e) {
    if (Generic.getNetworkStatus()) {
      CONFIG.selectedElement = e.target.getAttribute("id");
      var userDetails = localStorage.getItem("userDetails");
      userDetails = userDetails && JSON.parse(userDetails);
      if (userDetails && userDetails.email) {
        var r = e.target.getAttribute("row");
        var c = e.target.getAttribute("col");
        var catid = e.target.getAttribute("catid");
        if (r && c) {
          CONFIG.playerData = CONFIG.listData[r]["channel_details"][c];
          CONFIG.playerData.catid = catid;
          Loader.show();
          ApiHelper.getChannelData(CONFIG.playerData).then(
            function (response) {
              if (response.data) {
                CONFIG.channelDetails = response.data;
              }
              Loader.hide();
              window.changeUrl("player");
            },
            function (error) {}
          );
        }
      } else {
        document.querySelector(".home-container").style.background = "#000";
        window.changeUrl("login");
      }
    } else {
      var activeElement = document.activeElement;
      Popup.show(CONFIG.POPUP_TYPE.NETWORK, function () {
        activeElement.focus();
      });
    }
  }

  function focusHandler(e) {
    var type = e.target.getAttribute("type");
    var scrollclass = e.target.parentNode.getAttribute("scrollclass");
    var width = type === "square" ? 17.5 : 19.5;
    var c = e.target.getAttribute("col");
    NavHelper.scrollH(c, width, scrollclass, 5);
  }
};

module.exports = new FavouritesCtrl();
