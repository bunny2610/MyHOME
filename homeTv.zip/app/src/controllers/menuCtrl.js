var MenuCtrl = function () {
  var doT = require("../lib/dot");
  var template = require("../views/menuView.dot");
  var Promise = require("../lib/promise");
  var EventHandler = require("../events/event");
  var KEY = require("../utils/key");
  var CONFIG = require("../utils/config");
  var Generic = require("../utils/generic");
  var Popup = require("./popup/index");

  this.init = function () {
    return new Promise(function (fulfil, reject) {
      render();
      fulfil();
    });
  };

  this.destroy = function () {
    try {
      if (document.querySelector(".menu-container")) {
        var menuContent = document.querySelector(".menu-container");
        menuContent.innerHTML = "";
      }
    } catch (err) {}
  };

  function render() {
    const userDetails = JSON.parse(localStorage.getItem("userDetails"));
    var container = document.querySelector(".menu-container");
    var tempFn = doT.template(template);
    container.innerHTML = tempFn({
      data: {
        brand_logo: userDetails.brand_logo,
        sponser_logo: userDetails.sponsored_logo,
      },
    });

    document.addEventListener("focusin", (e) => {
      try {
        let currentElement = e.target;
        let isChildOfMenuContainer = false;
        while (currentElement) {
          if ([...currentElement.classList].includes("menu-container")) {
            isChildOfMenuContainer = true;
            break;
          }
          currentElement = currentElement.parentElement;
        }
        if (isChildOfMenuContainer) {
          container.style.width = "20%";
          container.querySelector(".menu-item-img.brand > img").src =
            userDetails.brand_logo;
          document.getElementById("brandLogo").padding = "10%";

          // brandLogo.style.position = "absolute";
          // brandLogo.style.top = "10%";
          container.querySelector(".menu-item-img.sponser > img").src =
            userDetails.sponsored_logo;
          document.getElementById("logo").style.marginTop = "180%";
          // document.querySelectorAll(".items").style.display = "block";

          for (let ele of container.querySelectorAll(".items")) {
            ele.style.display = "block";
          }
          for (let ele of container.querySelectorAll(".items")) {
            ele.style.font = "50px";
          }
          for (let ele of container.querySelectorAll(".icon")) {
            ele.style.width = "13%";
          }
          for (let ele of container.querySelectorAll(".icon")) {
            ele.style.marginLeft = "10%";
          }
          for (let ele of container.querySelectorAll(".icon")) {
            ele.style.marginRight = "10%";
          }
          for (let ele of container.querySelectorAll(".icons")) {
            ele.style.display = "none";
          }
        } else {
          container.style.width = "5%";
          container.querySelector(".menu-item-img.brand > img").src =
            userDetails.brand_logo_short;
          container.querySelector(".menu-item-img.sponser > img").src =
            userDetails.sponsored_logo_short;
          document.getElementById("logo").style.marginTop = "430%";
          // document.querySelectorAll(".items").style.display = "none";
          for (let ele of container.querySelectorAll(".items")) {
            ele.style.display = "none";
          }
          for (let ele of container.querySelectorAll(".icons")) {
            ele.style.display = "block";
          }
        }
      } catch (error) {}
    });

    EventHandler.init([
      {
        element: ".menu-list",
        events: [
          { eventType: "keydown", handler: KeydownHandler },
          { eventType: "click", handler: clickHandler },
        ],
      },
    ]);
    document.querySelector(".app-container").style.position = "fixed";
    setTimeout(function () {
      if (document.querySelector("li[name='" + CONFIG.selectedMenu + "']")) {
        document
          .querySelector("li[name='" + CONFIG.selectedMenu + "']")
          .focus();
        document
          .querySelector("li[name='" + CONFIG.selectedMenu + "']")
          .classList.add("active");
      } else {
        var firstChild = document.querySelector(".menu-item");
        firstChild.focus();
        firstChild.classList.add("active");
      }
      document.querySelector(".app-container").style.position = "relative";
    }, 100);
  }

  function KeydownHandler(e) {
    e.preventDefault();
    e.stopPropagation();
    var key = e.keyCode;
    switch (key) {
      case KEY.UP:
        if (e.target.previousElementSibling) {
          e.target.previousElementSibling.focus();
        }
        break;
      case KEY.DOWN:
        if (e.target.nextElementSibling) {
          e.target.nextElementSibling.focus();
        }
        break;
      case KEY.RIGHT:
        rightHandler(e);
        break;
      case KEY.ENTER:
        clickHandler(e);
        break;
      case KEY.BACK:
        var activeElement = document.activeElement;
        Popup.show(CONFIG.POPUP_TYPE.EXIT, function () {
          activeElement.focus();
        });
        break;
    }
  }

  function rightHandler(e) {
    if (
      document.querySelector(".banner-container").style.display !== "none" &&
      document.querySelector(".banner-container img")
    ) {
      document.querySelector(".banner-container img").focus();
    } else if (document.querySelector(".alphabates")) {
      document.querySelector("#r").focus();
    } else if (document.querySelector(".list .list-item")) {
      document.querySelector(".list .list-item").focus();
      document
        .querySelector(".list .list-item")
        .parentElement.previousElementSibling.scrollIntoView();
    } else if (document.querySelector("#logout")) {
      document.querySelector("#logout").focus();
    }
  }

  function clickHandler(e) {
    e.preventDefault();
    e.stopPropagation();
    CONFIG.selectedElement = "";
    CONFIG.searchText = "";
    CONFIG.marginTop = "";
    CONFIG.marginLeft = "";
    CONFIG.scrollclass = "";
    if (Generic.getNetworkStatus()) {
      if (CONFIG.interval) clearInterval(CONFIG.interval);
      if (CONFIG.polltimeout) clearTimeout(CONFIG.polltimeout);
      if (document.querySelector(".group")) {
        document.querySelector(".group").style.marginTop = "0em";
      }
      document.querySelector(".app-container").style.position = "fixed";
      if (document.querySelector(".menu-list .active")) {
        document.querySelector(".menu-list .active").classList.remove("active");
      }
      e.target.classList.add("active");
      var name = e.target.getAttribute("name");
      CONFIG.selectedMenu = name;
      document.querySelector(".home-container").style.background = "none";
      switch (name) {
        case "live":
          window.changeUrl("live");
          break;
        case "favourites":
          window.changeUrl("favourites");
          break;
        case "epg":
          window.changeUrl("epg");
          break;
        case "search":
          window.changeUrl("search");
          break;
        case "settings":
          checkLoginStatus();
          break;
      }
    }
  }

  function checkLoginStatus() {
    var userData = localStorage.getItem("userDetails2");
    userData = userData && JSON.parse(userData);
    document.querySelector(".home-container").style.background = "#000";
    if (userData && userData.email) {
      CONFIG.userData = userData;
      window.changeUrl("settings");
    } else {
      window.changeUrl("login");
    }
  }
};

module.exports = new MenuCtrl();
