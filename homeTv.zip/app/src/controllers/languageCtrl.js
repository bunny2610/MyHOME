var LanguageCtrl = function () {
  var doT = require("../lib/dot");
  var template = require("../views/languageView.dot");
  var NavHelper = require("../helper/nav-helper");
  var Promise = require("../lib/promise");
  var EventHandler = require("../events/event");
  var KEY = require("../utils/key");
  var CONFIG = require("../utils/config");
  var ApiHelper = require("../helper/api-helper");
  // var Generic = require("../utils/generic");
  // var Popup = require("./popup/index");
  var Loader = require("./popup/loader");

  this.init = function (data) {
    return new Promise(function (fulfil, reject) {
      ApiHelper.getChannelList().then(
        function (response) {
          CONFIG.appBackgroundData = response.data;
          render();
          fulfil();
        },
        function (error) {
          render();
          fulfil();
        }
      );
    });
  };

  function render() {
    getPackage().then(
      function (resp) {
        if (resp) {
          console.log(resp);
          renderData(resp);
        }
      },
      function (err) {
        renderData();
      }
    );
  }
  function renderData(data) {
    var container = document.querySelector(".app-container");
    var tempFn = doT.template(template);
    container.innerHTML = tempFn({ data: data });
    EventHandler.init([
      {
        element: ".language-page",
        events: [
          { eventType: "keydown", handler: KeydownHandler },
          { eventType: "click", handler: clickHandler },
          { eventType: "focus", handler: focusHandler },
        ],
      },
    ]);
    ApiHelper.getStoreUserDetails().then(
      function (resp) {
        // console.log(resp.data)
        if (resp && resp.data) {
          document.querySelector(".language-page").style.backgroundImage =
            "url(" + resp.data.app_background + ")";
        }
      },
      function () {}
    );

    Loader.hide();
    setTimeout(function () {
      if (document.querySelector(".packages")) {
        document.querySelector(".packages").focus();
      }
    }, 200);
  }

  function destroy() {}

  function getPackage() {
    return new Promise(function (resolve, reject) {
      ApiHelper.getPackage().then(
        function (resp) {
          if (resp && resp.data) {
            resolve(resp.data);
          }
          resolve(null);
        },
        function (err) {
          resolve(null);
        }
      );
    });
  }

  function KeydownHandler(e) {
    var key = e.keyCode;
    switch (key) {
      case KEY.LEFT:
        NavHelper.navigation(e, CONFIG.NAV_DIRECTION.HORIZONTAL);
        break;
      case KEY.RIGHT:
        NavHelper.navigation(e, CONFIG.NAV_DIRECTION.HORIZONTAL);
        break;
      case KEY.UP:
        if (document.getElementById(document.activeElement.dataset["up"])) {
          document.getElementById(document.activeElement.dataset["up"]).focus();
        }
        break;
      case KEY.DOWN:
        if (document.getElementById(document.activeElement.dataset["down"])) {
          document
            .getElementById(document.activeElement.dataset["down"])
            .focus();
        }
        break;
      case KEY.ENTER:
        clickHandler(e);
        break;
    }
  }

  ApiHelper.setPakage().then(
    function (resp) {
      if (resp && resp.data) {
        resolve(resp.data);
      }
      resolve(null);
    },
    function (err) {
      resolve(null);
    }
  );

  function clickHandler(e) {
    var name = e.target.getAttribute("name");
    if (name) {
      localStorage.setItem("package_name", name);
      ApiHelper.setPakage().then(
        function (response) {
          localStorage.setItem("PackageSet", JSON.stringify(response.data));
          if (response.data.status === "Package Updated Successfully") {
            window.changeUrl("live");
          } else {
            window.changeUrl("live");
          }
        },
        function (error) {}
      );
    }
  }
  function focusHandler(e) {}
};

module.exports = new LanguageCtrl();
