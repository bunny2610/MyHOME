var ListCtrl = function () {
  var doT = require("../lib/dot");
  var template = require("../views/listView.dot");
  var Promise = require("../lib/promise");
  var EventHandler = require("../events/event");
  var KEY = require("../utils/key");
  var CONFIG = require("../utils/config");
  var NavHelper = require("../helper/nav-helper");
  var ApiHelper = require("../helper/api-helper");
  var Generic = require("../utils/generic");
  var Popup = require("./popup/index");
  var Loader = require("./popup/loader");

  this.init = function (data) {
    return new Promise(function (fulfil, reject) {
      render(data);
      fulfil();
    });
  };

  this.destroy = function () {
    try {
      if (document.querySelector("#AppContainer")) {
        var ele = document.querySelector("#AppContainer");
        ele.parentNode.removeChild(ele);
      }
    } catch (err) {}
  };

  function render(data) {
    const bannerAvailable = data.banner_available === "YES";
    var container = document.querySelector(".home-content");
    var tempFn = doT.template(template);
    container.innerHTML = tempFn({
      data: !bannerAvailable
        ? data.category_details
        : data.category_details.slice(1),
    });
    EventHandler.init([
      {
        element: ".list-container",
        events: [
          { eventType: "keydown", handler: KeydownHandler },
          { eventType: "click", handler: clickHandler },
          { eventType: "focus", handler: focusHandler },
        ],
      },
    ]);

    setTimeout(function () {
      if (
        CONFIG.selectedElement &&
        document.querySelector("#" + CONFIG.selectedElement)
      ) {
        document.querySelector(".group").style.marginTop = CONFIG.marginTop;
        document.querySelector("#" + CONFIG.selectedElement).focus();
        document
          .querySelector("#" + CONFIG.selectedElement)
          .parentNode.childNodes[0].scrollIntoView();
        CONFIG.marginTop = 0;
        if (
          document.querySelector('[scrollclass="' + CONFIG.scrollclass + '"]')
        ) {
          // document.querySelector('[scrollclass="' + CONFIG.scrollclass + '"]').style.marginLeft=CONFIG.marginLeft;
          CONFIG.scrollclass = "";
          //   CONFIG.marginLeft = "";
        }
      }
    }, 200);
  }

  function KeydownHandler(e) {
    var key = e.keyCode ? e.keyCode : e.which;
    var r, row, h;
    switch (key) {
      case KEY.LEFT:
        NavHelper.navigation(e, CONFIG.NAV_DIRECTION.HORIZONTAL);
        break;
      case KEY.RIGHT:
        NavHelper.navigation(e, CONFIG.NAV_DIRECTION.HORIZONTAL);
        break;
      case KEY.UP:
        let screenWidth = window.innerWidth;
        // totalElements = e.target.parent
        NavHelper.navigation(e, CONFIG.NAV_DIRECTION.VERTICLE);

        r = e.target.getAttribute("up");
        row = e.target.getAttribute("row");
        h = e.target.parentNode.parentNode.offsetHeight / 16;
        if (r === "row-0") {
          document.querySelector(".group").style.marginTop = "0em";
        }
        if (document.querySelector("ul[row='" + r + "']")) {
          NavHelper.scrollVDynamic(row, h, ".group", "UP");
          document.querySelector("ul[row='" + r + "'] li").focus();
          document
            .querySelector("ul[row='" + r + "']")
            .parentNode.childNodes[0].scrollIntoView({
              block: "start",
            });
          if (r === "row-0") {
            document.querySelector(".group").style.marginTop = "0em";
          }
        } else if (
          document.querySelector(".banner-container").style.display !==
            "none" &&
          document.querySelector(".banner-container img")
        ) {
          document.querySelector(".banner-container img").focus();
          document.querySelector(".group").style.marginTop = "0em";
        } else if (document.querySelector(".menu-list .menu-item")) {
          document.querySelector(".menu-list .menu-item").focus();
        }
        break;
      case KEY.DOWN:
        NavHelper.navigation(e, CONFIG.NAV_DIRECTION.VERTICLE);

        r = e.target.getAttribute("down");
        row = e.target.getAttribute("row");
        h = e.target.parentNode.parentNode.offsetHeight / 16;
        row = parseInt(row) + 1;
        if (document.querySelector("ul[row='" + r + "']")) {
          NavHelper.scrollVDynamic(row, h, ".group", "DOWN");
          document.querySelector("ul[row='" + r + "'] li").focus();
          document
            .querySelector("ul[row='" + r + "']")
            .parentNode.childNodes[0].scrollIntoView({
              block: "start",
            });
        }
        break;
      case KEY.ENTER:
        clickHandler(e);
        break;
      case KEY.BACK:
        document.querySelector(".group").style.marginTop = "0em";
        document.querySelector(".menu-item").focus();
        break;
    }
  }

  function clickHandler(e) {
    if (Generic.getNetworkStatus()) {
      CONFIG.selectedElement = e.target.getAttribute("id");
      CONFIG.marginTop = document.querySelector(".group").style.marginTop;
      //   CONFIG.marginLeft = e.target.parentNode.style.marginLeft;
      CONFIG.scrollclass = e.target.parentNode.getAttribute("scrollclass");
      var userDetails = localStorage.getItem("userDetails");
      userDetails = userDetails && JSON.parse(userDetails);
      if (userDetails) {
        var r = e.target.getAttribute("row");
        var c = e.target.getAttribute("col");
        var catid = e.target.getAttribute("catid");
        const userDetails = JSON.parse(localStorage.getItem("userDetails2"));
        if (r && c) {
          if ((r == "0" && c == "0") || (userDetails && userDetails.email)) {
            CONFIG.playerData = CONFIG.listData[r]["channel_details"][c];
            CONFIG.playerData.catid = catid;
            CONFIG.playlistData = [CONFIG.listData[r]];
            Loader.show();
            ApiHelper.getChannelData(CONFIG.playerData).then(
              function (response) {
                if (response.data) {
                  document.querySelector(".group").style.marginTop = "0em";
                  document.querySelector(".app-container").style.position =
                    "relative";
                  CONFIG.channelDetails = response.data;
                  if (CONFIG.interval) {
                    clearInterval(CONFIG.interval);
                  }
                  window.changeUrl("player");
                }
                Loader.hide();
              },
              function (error) {}
            );
          } else {
            document.querySelector(".group").style.marginTop = "0em";
            document.querySelector(".home-container").style.background = "#000";
            CONFIG.selectedMenu = "login";
            window.changeUrl("login");
          }
        }
      } else {
        document.querySelector(".group").style.marginTop = "0em";
        document.querySelector(".home-container").style.background = "#000";
        CONFIG.selectedMenu = "login";
        window.changeUrl("login");
      }
    } else {
      var activeElement = document.activeElement;
      Popup.show(CONFIG.POPUP_TYPE.NETWORK, function () {
        activeElement.focus();
      });
    }
  }

  function focusHandler(e) {
    var type = e.target.getAttribute("type");
    var scrollclass = e.target.parentNode.getAttribute("scrollclass");
    var width = 0;
    switch (type) {
      case "square":
        width = 14.5;
        break;
      case "circle":
        width = 11.5;
        break;
      case "horizontal":
        width = 19.5;
        break;
      case "vertical":
        width = 13.5;
        break;
    }
    // data compare
    // e.target.parentNode.childNodes[0].scrollIntoView();
    var c = e.target.getAttribute("col");
    NavHelper.scrollH(c, width, scrollclass, 1);
  }
};

module.exports = new ListCtrl();
