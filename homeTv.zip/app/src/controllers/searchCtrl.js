var SearchCtrl = (function () {
    var doT = require('../lib/dot');
    var template = require("../views/searchView.dot");
    var Promise = require("../lib/promise");
    var EventHandler = require('../events/event');
    var KEY = require('../utils/key');
    var CONFIG = require('../utils/config');
    var Loader = require('./popup/loader');
    var SearchListCtrl = require('./searchListCtrl');
    var Popup=require('./popup/index');
    var menuCtrl = require('../controllers/menuCtrl');
    var searchText = '';
    var allData=null;

    this.init = function () {
        return new Promise(function (fulfil, reject) {
            render(null);
            fulfil();
        });
    };

    this.destroy = function () {
        try {

        } catch (err) {}
    };

    function render() {
        var container = document.querySelector(".home-container");
        var tempFn = doT.template(template);
        container.innerHTML = tempFn({});
        Loader.hide();
        EventHandler.init([
            {
                element: ".alphabates",
                events: [
                    {eventType: "keydown", handler: KeydownHandler},
                    {eventType: "click", handler: clickHandler}
                ]
            },
            {
                element: ".numbers",
                events: [
                    {eventType: "keydown", handler: numKeydownHandler},
                    {eventType: "click", handler: clickHandler}
                ]
            }
        ]);
        menuCtrl.init();
        if(CONFIG.homeData && CONFIG.homeData['category_details']){
            for(var i=0;i<CONFIG.homeData['category_details'].length;i++){
                if(CONFIG.homeData['category_details'][i]['category_name']==="All"){
                    allData =CONFIG.homeData['category_details'][i];
                    break;
                }
            }
        }
        document.querySelector('.group').style.marginTop ='0em';
        setTimeout(function(){
            document.querySelector('.app-container').style.position="relative";
        },200);
    }

    function numKeydownHandler(e) {
        var key = e.keyCode;
        switch (key) {
            case KEY.ENTER:
                clickHandler(e);
                break;
            case KEY.DOWN:
                if (document.querySelector('.list li'))
                    document.querySelector('.list li').focus();
                break;
            case KEY.UP:
                if (document.querySelector('#r'))
                    document.querySelector('#r').focus();
                break;
            case KEY.BACK:
                var activeElement=document.activeElement;
                Popup.show(CONFIG.POPUP_TYPE.EXIT,function () {
                    activeElement.focus();
                });
                break;
        }
    }

    function KeydownHandler(e) {
        var key = e.keyCode ? e.keyCode : e.which;
        switch (key) {
            case KEY.UP:
                if(document.querySelector('.menu-list')) {
                    if(document.querySelector('.menu-list .active'))
                        document.querySelector('.menu-list .active').focus();
                    else
                        document.querySelector('.menu-item').focus();
                }
                break;
            case KEY.DOWN:
                if (document.querySelector('#four'))
                    document.querySelector('#four').focus();
                break;
            case KEY.LEFT:
                if (e.target.previousElementSibling) {
                    e.target.previousElementSibling.focus();
                }
                break;
            case KEY.RIGHT:
                if (e.target.nextElementSibling) {
                    e.target.nextElementSibling.focus();
                }
                break;
            case KEY.ENTER:
                clickHandler(e);
                break;
            case KEY.BACK:
                var activeElement=document.activeElement;
                Popup.show(CONFIG.POPUP_TYPE.EXIT,function () {
                    activeElement.focus();
                });
                break;

        }
    }

    function clickHandler(e) {
        var text = e.target.innerHTML;
        switch (text) {
            case 'SPACE':
                searchText += ' ';
                break;
            case '&amp;':
            case '&':
                searchText += '&';
                break;
            case 'DELETE':
                searchText = searchText.length ? searchText.substring(0, searchText.length - 1) : '';
                break;
            default:
                searchText += text;
                break;
        }
        document.querySelector('.text-box').textContent = searchText;
        //document.querySelector('.text-box').value = searchText;
        searchFilter(searchText);
    }

    function searchFilter(searchText) {
            var filterData = [];
            if (searchText.length) {
                for (var i = 0; i < allData['channel_details'].length; i++) {
                    if ((allData['channel_details'][i]['channel_name'] && allData['channel_details'][i]['channel_name'].toLowerCase()).includes(searchText.toLowerCase())) {
                        filterData.push(allData['channel_details'][i]);
                    }
                }
                SearchListCtrl.init(filterData, allData.category_id);
            } else {
                SearchListCtrl.init(filterData);
            }
    }

});

module.exports = new SearchCtrl();
