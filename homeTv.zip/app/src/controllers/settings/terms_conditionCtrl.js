var terms_conditionCtrl = (function () {
    var doT = require('../../lib/dot');
    var template = require("../../views/settings/terms_conditionView.dot");
    var Promise = require("../../lib/promise");
    var EventHandler = require('../../events/event');
    var KEY = require('../../utils/key');
    var CONFIG = require('../../utils/config');
    var Generic = require('../../utils/generic');
    var Popup = require('../popup/index');
    var Loader = require('../popup/loader');

    this.init = function () {
        return new Promise(function (fulfil, reject) {
            render();
            fulfil();
        });
    };

    this.destroy = function () {
        try {
            var homeContent = document.querySelector(".account-container");
            if (homeContent) homeContent.innerHTML = "";
        }
        catch (err) {
        }
    };

    function render() {
        var container = document.querySelector(".account-container");
        var tempFn = doT.template(template);
        container.innerHTML = tempFn({data: CONFIG.userData});
    }
});

module.exports = new terms_conditionCtrl();
