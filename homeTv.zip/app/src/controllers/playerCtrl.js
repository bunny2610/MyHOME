var PlayerCtrl = function () {
  var doT = require("../lib/dot");
  var template = require("../views/playerView.dot");
  var Player = require("../utils/player");
  var EventHandler = require("../events/event");
  var KEY = require("../utils/key");
  var CONFIG = require("../utils/config");
  var NavHelper = require("../helper/nav-helper");
  var Generic = require("../utils/generic");
  var ApiHelper = require("../helper/api-helper");
  var playerListCtrl = require("./playerListCtrl");
  var Popup = require("./popup/index");

  var that = this;
  var duration, prevTime, state, isVideoEnded;
  var isfavAddRemove = false;

  this.init = function () {
    render();
  };

  this.destroy = function () {
    try {
      if (document.querySelector("#player-container")) {
        var ele = document.querySelector("#player-container");
        ele.parentNode.removeChild(ele);
      }
      if (Player) Player.destroy();
    } catch (err) {}
  };

  function render() {
    // document.querySelector(".preview-video-container").style.display = "none";
    // document.querySelector(".home-content").style.height = "100%";
    var container = document.querySelector(".home-content");
    var tempFn = doT.template(template);
    document.querySelector(".preview-video-title").style.display = "none";
    document.querySelector(".preview-video-description").style.display = "none";
    container.innerHTML = tempFn({
      data: CONFIG.playerData || {},
      platform: Generic.getDeviceOS(),
    });
    EventHandler.init([
      {
        element: "#dummy",
        events: [{ eventType: "keydown", handler: dummyKeydownHandler }],
      },

      {
        element: ".controls",
        events: [
          { eventType: "keydown", handler: controlsKeydownHandler },
          { eventType: "click", handler: controlsClickHandler },
        ],
      },
      // {
      //     element: "#progress-circle",
      //     events: [{eventType: "keydown", handler: seekbarKeydownHandler}]
      // },
      {
        element: "#progress-parent",
        events: [{ eventType: "click", handler: progressLineClick }],
      },
      {
        element: "#video",
        events: [{ eventType: "click", handler: playerClickHandler }],
      },
      {
        element: "#favourite-button",
        events: [
          { eventType: "keydown", handler: favouriteKeydownHandler },
          { eventType: "click", handler: favouriteClickHandler },
        ],
      },
      {
        element: ".player-list-container",
        events: [
          { eventType: "keydown", handler: listKeydownHandler },
          { eventType: "click", handler: listClickHandler },
          { eventType: "focus", handler: listFocusHandler },
        ],
      },
      //back-button
      //  {
      //   element: ".back-button",
      //    events: [{ eventType: "keydown", handler: backbuttonKeydownHandler },
      //  { eventType: "click", handler: backbuttonClickHandler },
      // ],
      // },
    ]);

    setTimeout(function () {
      document.getElementById("playpause").focus();
      controleVisibility();
    }, 100);
    document.querySelector(".app-container").style.position = "relative";
    that.playerLoader = document.getElementById("player-loader");
    that.playPause = document.getElementById("playpause");
    that.playerLoader = document.getElementById("player-loader");
    that.PlayerMessage = document.getElementById("message");
    that.currentTime = document.querySelector("#current-time");
    that.totalTime = document.querySelector("#total-time");
    that.progressLine = document.querySelector("#progress-line");
    that.playerFooter = document.querySelector(".player-footer");
    that.playerFooter.style.visibility = "visible";
    if (CONFIG.channelDetails["is_favorite"] === "YES") {
      document.querySelector("#favourite-button").src =
        "./images/favorite_active.png";
    } else {
      document.querySelector("#favourite-button").src = "./images/favorite.png";
    }
    updateChannelName();
    initPlayer();
    getRecommendedChannels();
  }

  function getRecommendedChannels() {
    playerListCtrl.init(CONFIG.playlistData).then(
      function () {},
      function () {}
    );
  }

  function updateChannelName() {
    if (CONFIG.channelDetails) {
      document.querySelector(".main-title").textContent =
        CONFIG.channelDetails.item_name;
      document.querySelector(".item-head").textContent =
        CONFIG.channelDetails.item_head;
      document.querySelector(".sub-title").textContent =
        CONFIG.channelDetails.item_description;
    }
    // if (CONFIG.channelDetails && CONFIG.channelDetails["list_details"]) {
    //   for (var i = 0; i < CONFIG.channelDetails["list_details"].length; i++) {
    //     for (
    //       var j = 0;
    //       j <
    //       CONFIG.channelDetails["list_details"][i]["channel_details"].length;
    //       j++
    //     ) {
    //       if (
    //         (CONFIG.playerData.channel_id || CONFIG.playerData.item_id) ===
    //         CONFIG.channelDetails["list_details"][i]["channel_details"][j][
    //           "item_id"
    //         ]
    //       ) {
    //         document.querySelector(".main-title").textContent =
    //           CONFIG.channelDetails["list_details"][i]["channel_details"][j][
    //             "title"
    //           ] +
    //           " " +
    //           CONFIG.channelDetails["list_details"][i]["channel_details"][j][
    //             "date_time"
    //           ];
    //         document.querySelector(".sub-title").textContent =
    //           CONFIG.channelDetails["list_details"][i]["channel_details"][j][
    //             "synopsis"
    //           ];
    //         break;
    //       }
    //     }
    //   }
    // }
  }

  function initPlayer() {
    that.playerLoader.style.display = "block";
    Player.init("video", CONFIG.playerData.item_link, playerCallback);
    duration = 0;
    isPlaying = true;
    state = "play";
    isVideoEnded = false;
  }

  function listKeydownHandler(e) {
    e.preventDefault();
    e.stopPropagation();
    var key = e.keyCode ? e.keyCode : e.which;
    var r, row, h;
    switch (key) {
      case KEY.LEFT:
        NavHelper.navigation(e, CONFIG.NAV_DIRECTION.HORIZONTAL);
        break;
      case KEY.RIGHT:
        NavHelper.navigation(e, CONFIG.NAV_DIRECTION.HORIZONTAL);
        break;
      case KEY.UP:
        r = e.target.getAttribute("up");
        row = e.target.getAttribute("row");
        h = e.target.parentNode.parentNode.offsetHeight / 16;
        if (document.querySelector("ul[row='" + r + "']")) {
          NavHelper.scrollVDynamic(row, h, "#list-wrapper1", "UP");
          document.querySelector("ul[row='" + r + "'] li").focus();
          document
            .querySelector("ul[row='" + r + "']")
            .parentNode.childNodes[0].scrollIntoView();
        } else if (document.querySelector("#favourite-button")) {
          that.playerFooter.style.bottom = "20em";
          document.querySelector(".player-list-container").style.bottom =
            "-1em";
          document.querySelector("#favourite-button").focus();
        }
        break;
      case KEY.DOWN:
        r = e.target.getAttribute("down");
        row = e.target.getAttribute("row");
        h = e.target.parentNode.parentNode.offsetHeight / 16;
        if (document.querySelector("ul[row='" + r + "']")) {
          NavHelper.scrollVDynamic(row, h, "#list-wrapper1", "DOWN");
          document.querySelector("ul[row='" + r + "'] li").focus();
          document
            .querySelector("ul[row='" + r + "']")
            .parentNode.childNodes[0].scrollIntoView();
        }
        break;
      case KEY.ENTER:
        listClickHandler(e);
        break;
      case KEY.BACK:
        if (that.playerFooter.style.visibility === "visible") {
          handleBackHidden();
        } else {
          backHandler();
        }
        break;
    }

    if (key === KEY.BACK || key === KEY.STOP) {
      return;
    }
    controleVisibility();
  }

  function listClickHandler(e) {
    if (Generic.getNetworkStatus()) {
      var r = e.target.getAttribute("row");
      var c = e.target.getAttribute("col");
      var catid = e.target.getAttribute("catid");
      const userDetails = JSON.parse(localStorage.getItem("userDetails2"));
      if (r && c) {
        if ((r == "0" && c == "0") || (userDetails && userDetails.email)) {
          CONFIG.playerData = CONFIG.playlistData[0]["channel_details"][c];
          CONFIG.playerData.catid = catid;
          listScrollUp();
          that.playerLoader.style.display = "block";
          ApiHelper.getChannelData(CONFIG.playerData).then(
            function (response) {
              if (response.data) {
                CONFIG.channelDetails = response.data;
                if (CONFIG.channelDetails["is_favorite"] === "YES") {
                  document.querySelector("#favourite-button").src =
                    "./images/favorite_active.png";
                } else {
                  document.querySelector("#favourite-button").src =
                    "./images/favorite.png";
                }
                // document.querySelector('.main-title').textContent = response.data.channel_name;
                if (Player) Player.destroy();
                updateChannelName();
                initPlayer();
                getRecommendedChannels();
                that.playerLoader.style.display = "none";
              }
            },
            function (error) {
              that.playerLoader.style.display = "none";
            }
          );
        } else {
          window.changeUrl("login");
        }
      }
      document.getElementById("playpause").focus();
    } else {
      var activeElement = document.activeElement;
      Popup.show(CONFIG.POPUP_TYPE.NETWORK, function () {
        activeElement.focus();
      });
    }
  }

  function listFocusHandler(e) {
    var type = e.target.getAttribute("type");
    var scrollclass = e.target.parentNode.getAttribute("scrollclass");
    var width = type === "square" ? 17.5 : 19.5;
    var c = e.target.getAttribute("col");
    NavHelper.scrollH(c, width, scrollclass, 2);
  }

  // back button KeydownHandler

  // function backbuttonKeydownHandler(e){
  //   e.preventDefault();
  //   e.stopPropagation();
  //   var key = e.keyCode ? e.keyCode : e.which;
  //   switch (key) {
  //     case KEY.UP:
  //       document.getElementById("playpause").focus();
  //       break;
  //     case KEY.DOWN:
  //       listScrollDown();
  //       break;
  //     case KEY.ENTER:
  //       favouriteClickHandler(e);
  //       break;
  //     case KEY.BACK:
  //       if (that.playerFooter.style.visibility === "visible") {
  //         handleBackHidden();
  //       } else {
  //         backHandler();
  //       }
  //       break;
  //   }

  // }

  function favouriteKeydownHandler(e) {
    e.preventDefault();
    e.stopPropagation();
    var key = e.keyCode ? e.keyCode : e.which;
    switch (key) {
      case KEY.UP:
        document.getElementById("playpause").focus();
        break;
      case KEY.DOWN:
        listScrollDown();
        break;
      case KEY.ENTER:
        favouriteClickHandler(e);
        break;
      case KEY.BACK:
        if (that.playerFooter.style.visibility === "visible") {
          handleBackHidden();
        } else {
          backHandler();
        }
        break;
    }
  }

  function listScrollDown() {
    if (document.querySelector(".list-item")) {
      that.playerFooter.style.bottom = "20em";
      document.querySelector(".player-list-container").style.bottom = "-1em";
      if (
        document.querySelector(
          "#id-" + (CONFIG.playerData.channel_id || CONFIG.playerData.item_id)
        )
      ) {
        document
          .querySelector(
            "#id-" + (CONFIG.playerData.channel_id || CONFIG.playerData.item_id)
          )
          .focus();
      } else {
        document.querySelector(".list-item").focus();
      }
    }
  }

  function listScrollUp() {
    if (document.querySelector(".list-item")) {
      that.playerFooter.style.bottom = "7em";
      document.querySelector(".player-list-container").style.bottom = "-16em";
      document.querySelector("#favourite-button").focus();
    }
  }

  // function backbuttonClickHandler(e){
  //   var userDetails = localStorage.getItem("userDetails");
  //   userDetails = userDetails && JSON.parse(userDetails);
  //   if (userDetails.email) {
  //     isfavAddRemove = true;
  //     ApiHelper.addRemoveFavorites({
  //       email: userDetails.email,
  //       channel_id: CONFIG.playerData.channel_id || CONFIG.playerData.item_id,
  //     }).then(
  //       function (response) {
  //         if (response.data.is_fav === "YES") {
  //           document.querySelector("#favourite-button").src =
  //             "./images/favorite_active.png";
  //         } else {
  //           document.querySelector("#favourite-button").src =
  //             "./images/favorite.png";
  //         }
  //       },
  //       function (error) {}
  //     );
  //   }

  // }

  function favouriteClickHandler(e) {
    var userDetails = localStorage.getItem("userDetails");
    userDetails = userDetails && JSON.parse(userDetails);
    if (userDetails.email) {
      isfavAddRemove = true;
      ApiHelper.addRemoveFavorites({
        email: userDetails.email,
        channel_id: CONFIG.playerData.channel_id || CONFIG.playerData.item_id,
      }).then(
        function (response) {
          if (response.data.is_fav === "YES") {
            document.querySelector("#favourite-button").src =
              "./images/favorite_active.png";
          } else {
            document.querySelector("#favourite-button").src =
              "./images/favorite.png";
          }
        },
        function (error) {}
      );
    } else {
      document.querySelector(".list-container").style.display = "none";
    }
  }

  function playerClickHandler(e) {
    e.preventDefault();
    e.stopPropagation();
    controleVisibility();
  }

  function progressLineClick(event) {
    var clickPosition =
      ((event.clientX - this.offsetLeft) / this.offsetWidth) * 100;
    var clickedTime =
      (parseInt(clickPosition, 10) * parseInt(duration, 10)) / 100;
    that.progressLine.style.width =
      parseInt((clickedTime / parseInt(duration, 10)) * 100, 10) + "%";
    that.currentTime.textContent = secondsToHms(clickedTime);
    Player.seek(clickedTime);
    controleVisibility();
  }

  function seekbarKeydownHandler(e) {
    e.preventDefault();
    e.stopPropagation();
    var key = e.keyCode ? e.keyCode : e.which;
    switch (key) {
      case KEY.LEFT:
        rewind();
        break;
      case KEY.RIGHT:
        forward();
        break;
      case KEY.DOWN:
        that.playPause.focus();
        // document.querySelector("#player-container").classList.add("related-video-list-gradient");
        // document.querySelector("#player-container").classList.add("video-header-gradient");
        break;
      case KEY.PAUSE:
        pause();
        break;
      case KEY.PLAY:
        play();
        break;
      case KEY.FORWARD:
        forward();
        break;
      case KEY.REWIND:
        rewind();
        break;
      case KEY.ENTER:
        toggleplay();
        break;
      case KEY.BACK:
        if (that.playerFooter.style.visibility === "visible") {
          handleBackHidden();
        } else {
          backHandler();
        }
        break;
    }
    if (key === KEY.BACK || key === KEY.STOP) {
      return;
    }
    controleVisibility();
  }

  function rewind() {
    if (!duration) {
      return;
    }
    if (isPlaying) {
      if (Player) Player.pause();
      isPlaying = false;
      that.playPause.setAttribute("class", "pause");
    }
    if (prevTime - 10 > 0) {
      prevTime -= 10;
      document.querySelector("#progress-line").style.width =
        parseInt((prevTime / parseInt(duration, 10)) * 100, 10) + "%";
    } else {
      prevTime = 0;
      document.querySelector("#progress-line").style.width = "0%";
    }

    that.currentTime.textContent = secondsToHms(prevTime);
    that.totalTime.textContent = secondsToHms(duration);

    if (this.autoplayTimer) {
      clearTimeout(this.autoplayTimer);
    }

    this.autoplayTimer = setTimeout(function () {
      CONFIG.playerData.progress = prevTime;
      Player.seek(prevTime);
      if (state === "play" && !isVideoEnded) {
        Player.play();
        document.getElementById("playpause").setAttribute("class", "play");
        isPlaying = true;
      } else if (isVideoEnded) {
        controlsClicked("playpause");
      }
    }, 1000);
  }

  function forward() {
    if (!duration) {
      return;
    }
    if (isPlaying) {
      Player.pause();
      isPlaying = false;
      that.playPause.setAttribute("class", "pause");
    }
    if (prevTime + 10 < parseInt(duration, 10)) {
      prevTime += 10;
      that.progressLine.style.width =
        parseInt((prevTime / parseInt(duration, 10)) * 100, 10) + "%";
    } else {
      that.progressLine.style.width = "100%";
    }

    that.currentTime.textContent = secondsToHms(prevTime);
    that.totalTime.textContent = secondsToHms(duration);

    if (this.autoplayTimer) {
      clearTimeout(this.autoplayTimer);
    }

    this.autoplayTimer = setTimeout(function () {
      CONFIG.playerData.progress = prevTime;
      Player.seek(prevTime);
      if (state === "play") {
        Player.play();
        that.playPause.setAttribute("class", "play");
        isPlaying = true;
      }
    }, 1000);
  }

  function dummyKeydownHandler(e) {
    e.preventDefault();
    e.stopPropagation();
    var key = e.keyCode ? e.keyCode : e.which;
    switch (key) {
      case KEY.LEFT:
      case KEY.RIGHT:
      case KEY.UP:
      case KEY.DOWN:
        listScrollDown();
        break;
      case KEY.BACK:
        if (that.playerFooter.style.visibility === "visible") {
          handleBackHidden();
        } else {
          backHandler();
        }
        break;
    }

    if (key === KEY.BACK || key === KEY.STOP) {
      return;
    }
    controleVisibility();
  }

  function controlsKeydownHandler(e) {
    e.preventDefault();
    e.stopPropagation();
    var key = e.keyCode ? e.keyCode : e.which;
    switch (key) {
      case KEY.PAUSE:
        pause();
        break;
      case KEY.PLAY:
        play();
        break;
      case KEY.FORWARD:
        forward();
        break;
      case KEY.REWIND:
        rewind();
        break;
      case KEY.ENTER:
        controlsClickHandler(e);
        break;
      case KEY.LEFT:
      case KEY.RIGHT:
        NavHelper.navigation(e, CONFIG.NAV_DIRECTION.HORIZONTAL);
        break;
      case KEY.UP:
        break;
      case KEY.DOWN:
        document.querySelector("#favourite-button").focus();
        break;
      case KEY.BACK:
        if (that.playerFooter.style.visibility === "visible") {
          handleBackHidden();
        } else {
          backHandler();
        }
        break;
    }

    if (key === KEY.BACK || key === KEY.STOP) {
      return;
    }
    controleVisibility();
  }

  function handleBackHidden() {
    that.playerFooter.style.visibility = "hidden";
    document.querySelector(".player-list-container").style.visibility =
      "hidden";
    document.querySelector(".player-overlay").style.visibility = "hidden";
    document.querySelector("#dummy").focus();
    if (document.querySelector(".list-item")) {
      if (
        document.querySelector(
          "#id-" + (CONFIG.playerData.channel_id || CONFIG.playerData.item_id)
        )
      ) {
        document
          .querySelector(
            "#id-" + (CONFIG.playerData.channel_id || CONFIG.playerData.item_id)
          )
          .focus();
      } else {
        document.querySelector(".list-item").focus();
      }
    }
  }

  function backHandler() {
    if (isfavAddRemove) {
      CONFIG.homeData = null;
    }
    if (Player) Player.destroy();
    window.history.back();
  }

  function controlsClickHandler(e) {
    e.stopPropagation();
    var name = e.target.getAttribute("name");
    controlsClicked(name);
  }

  function controlsClicked(name) {
    switch (name) {
      case "playpause":
        if (isVideoEnded) {
          isVideoEnded = false;
          that.playPause.setAttribute("class", "play");
          if (!CONFIG.playerData.progress) {
            document.querySelector("#progress-line").style.width = "0%";
            document.querySelector("#current-time").textContent = "00:00";
            isPlaying = true;
            initPlayer();
          } else {
            isPlaying = true;
            Player.init("video", CONFIG.playerData.FileURLSD, playerCallback);
          }
        } else {
          toggleplay();
        }
        break;
      case "rewind":
        rewind();
        break;
      case "forward":
        forward();
        break;
    }
    controleVisibility();
  }

  function toggleplay() {
    if (isPlaying) {
      pause();
    } else {
      play();
    }
  }

  function play() {
    if (Player) Player.play();
    that.playPause.setAttribute("class", "play");
    isPlaying = true;
    state = "play";
  }

  function pause() {
    if (Player) Player.pause();
    that.playPause.setAttribute("class", "pause");
    isPlaying = false;
    state = "pause";
  }

  function playerCallback(eventType, data, data1) {
    switch (eventType) {
      case "onloadedmetadata":
        that.totalTime.textContent = secondsToHms(data / 1000);
        that.currentTime.textContent = "00:00";
        that.playerLoader.style.display = "block";
        break;
      case "PLAYER_MSG_RESOLUTION_CHANGED":
      case "PLAYER_MSG_BITRATE_CHANGE":
        that.totalTime.textContent = secondsToHms(data / 1000);
        break;
      case "onplay":
        that.playPause.setAttribute("class", "play");
        break;
      case "onpause":
        that.playPause.setAttribute("class", "pause");
        break;
      case "ontimeupdate":
        if (parseInt(prevTime) !== parseInt(data / 1000)) {
          that.currentTime.textContent = secondsToHms(data / 1000);
          that.totalTime.textContent = secondsToHms(data1 / 1000);
          that.progressLine.style.width = parseInt((data / data1) * 100) + "%";
          that.playPause.setAttribute("class", "play");
        }
        prevTime = parseInt(data / 1000);
        duration = parseInt(data1 / 1000);
        break;
      case "onwaiting":
        that.playerLoader.style.display = "block";
        if (!Generic.getNetworkStatus()) {
          that.playerLoader.style.display = "none";
          that.PlayerMessage.style.display = "block";
          that.PlayerMessage.innerText = CONFIG.MESSAGE.NETWORK;
        }
        break;
      case "onseeking":
        break;
      case "onseeked":
        that.playerLoader.style.display = "none";
        break;
      case "onplaying":
        that.playerLoader.style.display = "none";
        break;
      case "onbufferingstart":
        duration = parseInt(data / 1000);
        that.playerLoader.style.display = "block";
        if (!Generic.getNetworkStatus()) {
          that.playerLoader.style.display = "none";
          that.PlayerMessage.style.display = "block";
          that.PlayerMessage.innerText = CONFIG.MESSAGE.NETWORK;
        }
        break;
      case "onbufferingprogress":
        break;
      case "onbufferingcomplete":
        duration = parseInt(data / 1000);
        that.playerLoader.style.display = "none";
        break;
      case "onended":
        that.progressLine.style.width = "100%";
        that.currentTime.textContent = secondsToHms(duration);
        that.playPause.setAttribute("class", "pause");
        isVideoEnded = true;
        controleVisibility();
        break;
      case "onplaybackerror":
        break;
      case "networkError":
      case "PLAYER_ERROR_CONNECTION_FAILED":
        break;
      default:
        break;
    }
  }

  function secondsToHms(d) {
    if (!d || isNaN(d)) {
      return "00:00";
    }
    d = Number(d);
    var h = Math.floor(d / 3600);
    var m = Math.floor((d % 3600) / 60);
    var s = Math.floor((d % 3600) % 60);

    var hDisplay = h < 10 ? "0" + h : h;
    var mDisplay = m < 10 ? "0" + m : m;
    var sDisplay = s < 10 ? "0" + s : s;
    if (h === 0) {
      return mDisplay + ":" + sDisplay;
    } else {
      return hDisplay + ":" + mDisplay + ":" + sDisplay;
    }
  }

  function controleVisibility() {
    if (that.playerFooter && that.playerFooter.style.visibility === "hidden") {
      that.playerFooter.style.visibility = "visible";
      document.querySelector(".player-list-container").style.visibility =
        "visible";
      document.querySelector(".player-overlay").style.visibility = "visible";
      listScrollDown();
    }

    if (this.controlVisibilityTimer) {
      clearTimeout(this.controlVisibilityTimer);
    }

    this.controlVisibilityTimer = setTimeout(function () {
      if (that.playerFooter) {
        listScrollUp();
        that.playerFooter.style.visibility = "hidden";
        document.querySelector(".player-list-container").style.visibility =
          "hidden";
        document.querySelector(".player-overlay").style.visibility = "hidden";
        document.querySelector("#dummy").focus();
      }
    }, 6000);
  }

  document.addEventListener("visibilitychange", function () {
    if (document.visibilityState === "visible") {
      if (Player) Player.play();
    } else {
      if (Player) Player.pause();
    }
  });

  window.networkDetection = function (status) {
    if (status) {
      setTimeout(function () {
        if (Player) Player.destroy();
        that.PlayerMessage.style.display = "none";
        that.PlayerMessage.innerText = "";
        initPlayer();
      }, 1000);
    } else {
    }
  };
};

module.exports = new PlayerCtrl();
