var EpgCtrl = function () {
  var doT = require("../lib/dot");
  var template = require("../views/epgView.dot");
  var Promise = require("../lib/promise");
  var Loader = require("./popup/loader");

  this.init = function () {
    return new Promise(function (fulfil, reject) {
      render(null);
      fulfil();
    });
  };

  this.destroy = function () {
    try {
    } catch (err) {}
  };

  function render(data) {
    var container = document.querySelector(".home-container");
    var tempFn = doT.template(template);
    container.innerHTML = tempFn({});
    Loader.hide();
    document.querySelector(".group").style.marginTop = "0em";
  }
};

module.exports = new EpgCtrl();
