var PreviewVideoCtrl = function () {
  var doT = require("../lib/dot");
  var template = require("../views/previewVideo.dot");
  var NavHelper = require("../helper/nav-helper");
  var Promise = require("../lib/promise");
  var EventHandler = require("../events/event");
  var KEY = require("../utils/key");
  var CONFIG = require("../utils/config");
  var ApiHelper = require("../helper/api-helper");
  var Generic = require("../utils/generic");
  var Popup = require("./popup/index");
  var Loader = require("./popup/loader");
  var Player = require("../utils/player");

  CONFIG.interval = null;
  var currentIndex = 0;
  var carouselData = {};

  this.init = function ({ data, previewVideoLink, previewVideoDetail }) {
    return new Promise(function (fulfil, reject) {
      carouselData = data.category_details[0]; //['channel_details'];gulp
      render({ data, previewVideoLink, previewVideoDetail });
      fulfil();
    });
  };

  function destroy() {
    try {
      if (document.querySelector(".home-tile-container")) {
        document.querySelector(".home-tile-container").innerHTML = "";
      }
      clearInterval(CONFIG.interval);
    } catch (err) {}
  }

  function render({ data, previewVideoLink, previewVideoDetail }) {
    const bannerAvailable = data.banner_available === "YES";
    data = data.category_details[0];
    // console.log("Indide Preview Container: ", data, previewVideoLink);

    var container = document.querySelector(".preview-video-container");
    if (bannerAvailable) {
      container.style["display"] = "none";
      document.querySelector(".banner-container").style["display"] = "block";
    }

    var tempFn = doT.template(template);
    // console.log("==> Preview Video Templaye: ", tempFn({}));
    container.innerHTML = tempFn({ data: previewVideoDetail });
    // console.log(previewVideoDetail)

    Player.init("preview-video", previewVideoLink, (eventType, data, data1) => {
      // console.log("==> PLayer Event Triggered: ", eventType, data, data1);
    });

    EventHandler.init([
      {
        element: ".preview-video-container",
        events: [
          { eventType: "keydown", handler: KeydownHandler },
          { eventType: "click", handler: clickHandler },
          { eventType: "focus", handler: focusHandler },
        ],
      },
    ]);
  }

  function KeydownHandler(e) {
    e.stopPropagation();
    var key = e.keyCode;
    switch (key) {
      case KEY.DOWN:
        if (document.querySelector(".list .list-item")) {
          document.querySelector(".list .list-item").focus();
        }
        break;
      case KEY.UP:
        if (document.querySelector(".menu-item")) {
          document.querySelector(".group").style.marginTop = "0em";
          document.querySelector(".menu-item").focus();
        }
        break;
      case KEY.ENTER:
        clickHandler(e);
        break;
      case KEY.BACK:
        document.querySelector(".group").style.marginTop = "0em";
        document.querySelector(".menu-item").focus();
        // var activeElement=document.activeElement;
        // Popup.show(CONFIG.POPUP_TYPE.EXIT,function () {
        //     activeElement.focus();
        // });
        break;
    }
  }

  function clickHandler(e) {
    e.stopPropagation();
    if (Generic.getNetworkStatus()) {
      CONFIG.selectedElement = "banner-image";
      document.querySelector(".group").style.marginTop = "0em";
      var userDetails = localStorage.getItem("userDetails2");
      userDetails = userDetails && JSON.parse(userDetails);
      if (userDetails && userDetails.email) {
        CONFIG.playerData = carouselData["channel_details"][currentIndex];
        CONFIG.playerData.catid = carouselData["category_id"];
        Loader.show();
        ApiHelper.getChannelData(CONFIG.playerData).then(
          function (response) {
            if (response.data) {
              CONFIG.channelDetails = response.data;
            }
            Loader.hide();
            destroy();
            window.changeUrl("player");
          },
          function (error) {}
        );
      } else {
        document.querySelector(".home-container").style.background = "#000";
        CONFIG.selectedMenu = "login";
        window.changeUrl("login");
      }
    } else {
      var activeElement = document.activeElement;
      Popup.show(CONFIG.POPUP_TYPE.NETWORK, function () {
        activeElement.focus();
      });
    }
  }

  function focusHandler(e) {}
};

module.exports = new PreviewVideoCtrl();
