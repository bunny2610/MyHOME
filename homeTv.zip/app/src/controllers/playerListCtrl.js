var PlayerListCtrl = (function () {
    var doT = require('../lib/dot');
    var template = require("../views/playerListView.dot");
    var Promise = require("../lib/promise");

    this.init = function (data) {
        return new Promise(function (fulfil, reject) {
            render(data);
            fulfil();
        });
    };

    this.destroy = function () {
        try {
            // if (document.querySelector('#AppContainer')) {
            //     var ele = document.querySelector('#AppContainer');
            //     ele.parentNode.removeChild(ele);
            // }
        } catch (err) {}
    };

    function render(data) {
        var container = document.querySelector(".player-list-container");
        var tempFn = doT.template(template);
        container.innerHTML = tempFn({data: data});
    }

});

module.exports = new PlayerListCtrl();
