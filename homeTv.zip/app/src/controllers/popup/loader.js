(function () {
    var doT = require('../../lib/dot');
    var template = require("../../views/popup/loader.dot");

    var Loader = {};

    Loader.show = function () {
        var container = document.getElementById("progress-loader");
        var tempFn = doT.template(template);
        container.innerHTML = tempFn({});
    };

    Loader.hide = function () {
        document.getElementById("progress-loader").innerHTML = '';
    };

    module.exports = Loader;
})();
