(function () {
    var doT = require('../../lib/dot');
    var template = require("../../views/popup/back-popup.dot");
    var KEY = require("../../utils/key");
    var EventHandler = require("../../events/event");
    var NavHelper = require("../../helper/nav-helper");
    var CONFIG = require('../../utils/config');
    var LogoutPopup = {};

    LogoutPopup.init = function (callback,data) {
        LogoutPopup.callback = callback;
        var container = document.getElementById("AppPopup");
        var tempFn = doT.template(template);
        container.innerHTML = tempFn({data:data});
        EventHandler.init({
            element: "#popup-action-btn",
            events: [{eventType: "keydown", handler: LogoutPopup.keydownHandler},
                {eventType: "click", handler: LogoutPopup.clickHandler}
            ]
        });
        setTimeout(function () {
            document.querySelector("#popup-action-btn").children[1].focus();
            CONFIG.loaderActive = false;
        }, 100);
    };

    LogoutPopup.keydownHandler = function (e) {
        e.stopPropagation();
        e.preventDefault();
        var key = e.keyCode ? e.keyCode : e.which;
        switch (key) {
            case KEY.ENTER:
                doneHandler(e);
                break;
            case KEY.BACK:
                document.getElementById("AppPopup").innerHTML = '';
                LogoutPopup.callback("cancel");
                break;
            case KEY.LEFT:
            case KEY.RIGHT:
                NavHelper.navigation(e, CONFIG.NAV_DIRECTION.HORIZONTAL);
                break;
        }
    };

    LogoutPopup.clickHandler = function (e) {
        e.stopPropagation();
        e.preventDefault();
        doneHandler(e);
    };

    function doneHandler(e) {
        var name = e.target.getAttribute("name");
        document.getElementById("AppPopup").innerHTML = '';
        if (LogoutPopup.callback) {
            LogoutPopup.callback(name);
        }
    }

    LogoutPopup.hide=function(){
        document.getElementById("AppPopup").innerHTML = '';
        if (LogoutPopup.callback) {
            LogoutPopup.callback('cancel');
        }
    };

    module.exports = LogoutPopup;
})();
