(function () {

    var CONFIG = require('../../utils/config');
    var ExitPopup = require('./exit-popup');
    var NetworkPopup = require('./network-popup');
    var LogoutPopup = require('./logout-popup');
    var BackToTopPopup = require('./back-popup');
    var Popup = {};

    Popup.show = function (type, successcallback, data) {
        CONFIG.loaderActive = true;
        Popup.type=type;
        switch (type) {
            case CONFIG.POPUP_TYPE.EXIT:
                ExitPopup.init(successcallback, data);
                break;
            case CONFIG.POPUP_TYPE.NETWORK:
                NetworkPopup.init(successcallback,data);
                break;
            case CONFIG.POPUP_TYPE.LOGOUT:
                LogoutPopup.init(successcallback,data);
                break;
            case CONFIG.POPUP_TYPE.BACK_TO_TOP:
                BackToTopPopup.init(successcallback,data);
                break;
        }
    };

    Popup.hide = function () {
        CONFIG.loaderActive = false;
        switch (Popup.type) {
            case CONFIG.POPUP_TYPE.EXIT:
                ExitPopup.hide();
                break;
            case CONFIG.POPUP_TYPE.NETWORK:
                NetworkPopup.hide();
                break;
            case CONFIG.POPUP_TYPE.LOGOUT:
                LogoutPopup.hide();
                break;
            case CONFIG.POPUP_TYPE.BACK_TO_TOP:
                BackToTopPopup.hide();
                break;
        }
        Popup.type='';
    };

    module.exports = Popup;
})();
