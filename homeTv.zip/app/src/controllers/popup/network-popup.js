(function () {
    var doT = require('../../lib/dot');
    var template = require("../../views/popup/network-popup.dot");
    var KEY = require("../../utils/key");
    var EventHandler = require("../../events/event");
    var NavHelper = require("../../helper/nav-helper");
    var CONFIG = require('../../utils/config');
    var NetworkPopup = {};

    NetworkPopup.init = function (callback,data) {
        NetworkPopup.callback = callback;
        var container = document.getElementById("AppPopup");
        var tempFn = doT.template(template);
        container.innerHTML = tempFn({data:data});
        EventHandler.init({
            element: "#popup-action-btn",
            events: [{eventType: "keydown", handler: NetworkPopup.keydownHandler},
                {eventType: "click", handler: NetworkPopup.clickHandler}
            ]
        });
        setTimeout(function () {
            document.querySelector("#popup-action-btn").children[0].focus();
            CONFIG.loaderActive = false;
        }, 100);
    };

    NetworkPopup.keydownHandler = function (e) {
        e.stopPropagation();
        e.preventDefault();
        var key = e.keyCode ? e.keyCode : e.which;
        switch (key) {
            case KEY.ENTER:
                doneHandler(e);
                break;
            case KEY.LEFT:
            case KEY.RIGHT:
                NavHelper.navigation(e, CONFIG.NAV_DIRECTION.HORIZONTAL);
                break;
        }
    };

    NetworkPopup.clickHandler = function (e) {
        e.stopPropagation();
        e.preventDefault();
        doneHandler(e);
    };

    function doneHandler(e) {
        document.getElementById("AppPopup").innerHTML = '';
        if (NetworkPopup.callback) {
            NetworkPopup.callback(e.target.getAttribute("name"));
        }
    }

    NetworkPopup.hide=function(){
        document.getElementById("AppPopup").innerHTML = '';
        if (NetworkPopup.callback) {
            NetworkPopup.callback('done');
        }
    };

    module.exports = NetworkPopup;
})();
