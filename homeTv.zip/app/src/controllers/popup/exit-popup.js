(function () {
    var doT = require('../../lib/dot');
    var template = require("../../views/popup/exit-popup.dot");
    var KEY = require("../../utils/key");
    var EventHandler = require("../../events/event");
    var NavHelper = require("../../helper/nav-helper");
    var CONFIG = require('../../utils/config');
    var Generic = require('../../utils/generic');
    var ExitPopup = {};

    ExitPopup.init = function (callback) {
        ExitPopup.callback = callback;
        var container = document.getElementById("AppPopup");
        var tempFn = doT.template(template);
        container.innerHTML = tempFn({});
        EventHandler.init({
            element: "#popup-action-btn",
            events: [{eventType: "keydown", handler: ExitPopup.keydownHandler},
                {eventType: "click", handler: ExitPopup.clickHandler}
            ]
        });
        setTimeout(function () {
            document.querySelector("#popup-action-btn").children[1].focus();
            CONFIG.loaderActive = false;
        }, 100);
    };

    ExitPopup.keydownHandler = function (e) {
        var key = e.keyCode ? e.keyCode : e.which;
        switch (key) {
            case KEY.ENTER:
                doneHandler(e);
                break;
            case KEY.BACK:
                document.getElementById("AppPopup").innerHTML = '';
                ExitPopup.callback("cancel");
                break;
            case KEY.LEFT:
            case KEY.RIGHT:
                NavHelper.navigation(e, CONFIG.NAV_DIRECTION.HORIZONTAL);
                break;
        }
    };

    ExitPopup.clickHandler = function (e) {
        e.stopPropagation();
        e.preventDefault();
        doneHandler(e);
    };

    function doneHandler(e) {
        document.getElementById("AppPopup").innerHTML = '';
        if(e.target.getAttribute("name")==='done'){
            Generic.exit();
        }else if (ExitPopup.callback) {
            ExitPopup.callback(e.target.getAttribute("name"));
        }
    }


    ExitPopup.hide=function(){
        document.getElementById("AppPopup").innerHTML = '';
        if (ExitPopup.callback) {
            ExitPopup.callback('done');
        }
    };

    module.exports = ExitPopup;
})();
