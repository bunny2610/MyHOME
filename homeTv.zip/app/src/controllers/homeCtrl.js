const player = require("../utils/player");

var HomeCtrl = function () {
  var doT = require("../lib/dot");
  var template = require("../views/homeView.dot");
  var Promise = require("../lib/promise");
  var ApiHeper = require("../helper/api-helper");
  var menuCtrl = require("../controllers/menuCtrl");
  var bannerCtrl = require("../controllers/bannerCtrl");
  var previewVideoCtrl = require("../controllers/previewVideoCtrl");
  var listCtrl = require("../controllers/listCtrl");
  var Loader = require("./popup/loader");
  var CONFIG = require("../utils/config");
  const Player = require("../utils/player");

  this.init = function () {
    playLoadingVideo();
    return new Promise(function (fulfil, reject) {
      if (!CONFIG.homeData) {
        ApiHeper.getChannelList().then(
          function (response) {
            if (response && response.data && response.data.id_token) {
              var data = parseJwt(response.data.id_token);
              CONFIG.homeData = data;
              const bannerAvailable = data.banner_available === "YES";
              if (bannerAvailable) {
                CONFIG.bannerData = data.category_details[0]["channel_details"];
                CONFIG.listData = data.category_details.slice(1);
              } else {
                CONFIG.listData = data.category_details;
              }
              render(data);
            }
            fulfil();
          },
          function (error) {
            render();
            fulfil();
          }
        );
      } else {
        render(CONFIG.homeData);
        fulfil();
      }
    });
  };

  function parseJwt(token) {
    var base64Url = token.split(".")[1];
    var base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/");
    var jsonPayload = decodeURIComponent(
      window
        .atob(base64)
        .split("")
        .map(function (c) {
          return "%" + ("00" + c.charCodeAt(0).toString(16)).slice(-2);
        })
        .join("")
    );
    var result = JSON.parse(jsonPayload);
    return result.data;
  }

  this.destroy = function () {
    try {
      var bannerContainer = document.querySelector(".banner-container");
      var homeContent = document.querySelector(".home-content");
      if (bannerContainer) bannerContainer.innerHTML = "";
      if (homeContent) homeContent.innerHTML = "";
      if (Player) Player.destroy();
    } catch (err) {}
  };

  function playLoadingVideo() {
    var container = document.getElementById("AppContainer");
    var tempFn = doT.template(template);
    container.innerHTML = tempFn({});
    const homeContainer = document.querySelector(".home-container");
    const userDetails = JSON.parse(localStorage.getItem("userDetails"));
    if (
      userDetails["VOD_SUPPORT"] === "ENABLE"
      //  && localStorage.getItem("isAdViewed") !== "true"
    ) {
      Loader.hide();

      const adVideo = document.createElement("video");
      adVideo.id = "ad-video";
      adVideo.style.width = "100%";
      adVideo.style.height = "100%";
      homeContainer.parentElement.insertBefore(adVideo, homeContainer);
      var videoUrl = userDetails["is_ad_notification_url"];
      // var videoUrl = "./splash.mp4";
      Player.init("ad-video", videoUrl, function (eventType, data, data1) {
        switch (eventType) {
          case "onloadeddata":
            // Player.play();
            break;
          case "onended":
            adVideo.remove();
            localStorage.setItem("isAdViewed", "true");
            homeContainer.style.display = "unset";
            Player.destroy();
            resolve();
            break;
        }
      });
      player.play();
    } else {
      homeContainer.style.display = "unset";
      resolve();
    }
  }

  function render(data) {
    let previewVideoLink, previewVideoDetail;
    if (
      data.category_details.length > 0 &&
      data.category_details[0].channel_details.length > 0 &&
      !CONFIG.playerData
    ) {
      previewVideoLink = data.category_details[0].channel_details[0].item_link;
      previewVideoDetail = data.category_details[0].channel_details[0];
    } else {
      previewVideoLink = CONFIG.playerData.item_link;
      previewVideoDetail = CONFIG.playerData;
    }
    return new Promise(function (fulfil, reject) {
      var container = document.getElementById("AppContainer");
      var tempFn = doT.template(template);
      container.innerHTML = tempFn({});
      new Promise((resolve, reject) => {
        // ad block //
        // const homeContainer = document.querySelector(".home-container");
        // const userDetails = JSON.parse(localStorage.getItem("userDetails"));
        // if (
        //   userDetails["VOD_SUPPORT"] === "ENABLE"
        //   //  && localStorage.getItem("isAdViewed") !== "true"
        // ) {
        //   Loader.hide();
        //   const adVideo = document.createElement("video");
        //   adVideo.id = "ad-video";
        //   adVideo.style.width = "100%";
        //   adVideo.style.height = "100%";
        //   homeContainer.parentElement.insertBefore(adVideo, homeContainer);
        //   // var videoUrl = userDetails["is_ad_notification_url"];
        //   var videoUrl = "./splash.mp4";
        //   Player.init("ad-video", videoUrl, function (eventType, data, data1) {
        //     switch (eventType) {
        //       case "onloadeddata":
        //         // Player.play();
        //         break;
        //       case "onended":
        //         adVideo.remove();
        //         localStorage.setItem("isAdViewed", "true");
        //         homeContainer.style.display = "unset";
        //         Player.destroy();
        //         resolve();
        //         break;
        //     }
        //   });
        //   player.play();
        // } else {
        //   homeContainer.style.display = "unset";
        //   resolve();
        // }
        // end//
      }).finally(() => {
        // Loader.show();
        document.body.style.backgroundImage =
          "url(" + data.app_background + ")";
        menuCtrl.init(data);
        bannerCtrl.init(data);
        previewVideoCtrl.init({ data, previewVideoLink, previewVideoDetail });
        listCtrl.init(data);
        // Loader.hide();
        document.querySelector(".app-container").style.position = "relative";
        fulfil();
      });
    });
  }
};

module.exports = new HomeCtrl();
