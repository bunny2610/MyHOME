const { keydownHandler } = require("./popup/exit-popup");

var SettingCtrl = function () {
  var doT = require("../lib/dot");
  var template = require("../views/settingView.dot");
  var Promise = require("../lib/promise");
  var EventHandler = require("../events/event");
  var KEY = require("../utils/key");
  var CONFIG = require("../utils/config");
  var Generic = require("../utils/generic");
  var Popup = require("./popup/index");
  var Loader = require("./popup/loader");
  var ProfileCtrl = require("./settings/profileCtrl");
  var supportCtrl = require("./settings/supportCtrl");
  var packageCtrl = require("./settings/packageCtrl");
  var privacyCtrl = require("./settings/privacyCtrl");
  var cookieCtrl = require("./settings/cookieCtrl");
  var termsConditionCtrl = require("./settings/termsConditionCtrl");
  var aboutCtrl = require("./settings/aboutCtrl");
  var signOutCtrl = require("./settings/signOutCtrl");

  this.init = function () {
    return new Promise(function (fulfil, reject) {
      render();
      fulfil();
    });
  };

  this.destroy = function () {
    try {
      var homeContent = document.querySelector(".home-content");
      if (homeContent) homeContent.innerHTML = "";
    } catch (err) {}
  };

  function render() {
    // document.querySelector(".preview-video-container").style.display = "none";
    // document.querySelector(".home-content").style.height = "100%";
    var container = document.querySelector(".home-container");

    var tempFn = doT.template(template);
    container.innerHTML = tempFn({
      data: CONFIG.userData,
    });
    Loader.hide();
    EventHandler.init([
      {
        element: ".setting-menu",
        events: [
          { eventType: "keydown", handler: KeydownHandler },
          { eventType: "click", handler: clickHandler },
        ],
      },
    ]);
  }
  // EventHandler.init([
  //   {
  //     element: "#logout",
  //     events: [
  //       { eventType: "keydown", handler: KeydownHandler },
  //       { eventType: "click", handler: clickHandler },
  //     ],
  //   },
  // ]);
  // document.querySelector(".group").style.marginTop = "0em";
  // setTimeout(function () {
  //   document.querySelector(".app-container").style.position = "relative";
  // }, 200);

  function KeydownHandler(e) {
    e.preventDefault();
    var key = e.keyCode;
    switch (key) {
      case KEY.LEFT:
        if (e.target.previousElementSibling) {
          e.target.previousElementSibling.focus();
        } else if (document.querySelector(".menu-list .active")) {
          document.querySelector(".menu-list .active").focus();
        } else if (document.querySelector(".menu-list")) {
          document.querySelector(".menu-list").focus();
        }

        break;
      case KEY.ENTER:
        clickHandler(e);
        break;
      case KEY.RIGHT:
        if (e.target.nextElementSibling) {
          e.target.nextElementSibling.focus();
        }
        break;
      case KEY.BACK:
        var activeElement = document.activeElement;
        Popup.show(CONFIG.POPUP_TYPE.EXIT, function () {
          activeElement.focus();
        });
        break;
    }
  }
  function clickHandler(e) {
    e.preventDefault();
    e.stopPropagation();
    var name = e.target.getAttribute("name");
    switch (name) {
      case "profile":
        ProfileCtrl.init();
        break;
      case "support":
        supportCtrl.init();
        break;
      case "package":
        packageCtrl.init();
        break;
      case "privacy":
        privacyCtrl.init();
        break;
      case "cookie":
        cookieCtrl.init();
        break;
      case "t&c":
        termsConditionCtrl.init();
        break;
      case "about":
        aboutCtrl.init();
        break;
      case "sign-out":
        signOutCtrl.init();
        break;
    }
  }
  //   function KeydownHandler(e) {
  //     e.preventDefault();
  //     var key = e.keyCode ? e.keyCode : e.which;
  //     switch (key) {
  //       case KEY.UP:
  //         if (document.querySelector(".menu-list")) {
  //           document.querySelector(".menu-list .active").focus();
  //         }
  //         break;
  //       case KEY.ENTER:
  //         clickHandler(e);
  //         break;
  //       case KEY.BACK:
  //         var activeElement = document.activeElement;
  //         Popup.show(CONFIG.POPUP_TYPE.EXIT, function () {
  //           activeElement.focus();
  //         });
  //         break;
  //     }
  //   }

  //   function clickHandler() {
  //     if (Generic.getNetworkStatus()) {
  //       var activeElement = document.activeElement;
  //       Popup.show(CONFIG.POPUP_TYPE.LOGOUT, function (val) {
  //         if (val === "done") {
  //           localStorage.setItem("userDetails2", "");
  //           localStorage.clear("userDetails2", "");
  //           CONFIG.homeData = null;
  //           window.changeUrl("live");
  //           CONFIG.selectedMenu = "live";
  //         } else {
  //           activeElement.focus();
  //         }
  //       });
  //     }
  //   }
};

module.exports = new SettingCtrl();
