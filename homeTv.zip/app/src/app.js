var router = require("./router");
var NavHelper = require("./helper/nav-helper");

window.addEventListener("load", function () {
  var videoElement = document.createElement("video");
  videoElement.id="splash-video";
  videoElement.preload='auto';
  videoElement.autoplay='true';
  videoElement.muted=true;
  videoElement.src="./splash.mp4";
  videoElement.onended=videoEnded;
  document.getElementById("AppContainer").appendChild(videoElement);
  function videoEnded(){
    videoElement.remove();
    router.start();
  }
});

window.addEventListener("mouseclick", function (event) {
  try {
    if (
      event &&
      event.target &&
      !event.target.getAttribute("tabIndex") &&
      event.target.tagName !== "INPUT" &&
      event.target.tagName !== "I" &&
      !event.target.parentElement.getAttribute("tabIndex")
    ) {
      event.stopPropagation();
      event.preventDefault();
    }
  } catch (e) {}
});

window.addEventListener("mousedown", window.mouseClickHandler);

window.addEventListener("offline", function (event) {
  window.Network.connected = false;
  if (window.networkDetection) window.networkDetection(false);
});

window.addEventListener("online", function (event) {
  window.Network.connected = true;
  if (window.networkDetection) window.networkDetection(true);
});

document.addEventListener("mousewheel", function (e) {
  var wDelta = e.wheelDelta < 0 ? "down" : "up";
  var section =
    document.activeElement.parentNode.getAttribute("section") ||
    document.activeElement.getAttribute("section");
  scrollHandler(e, wDelta, section);
});

function scrollHandler(e, wDelta, section) {
  if (wDelta === "down") {
    downHandler(section);
  } else if (wDelta === "up") {
    upHandler(section);
  }
}

function listScrollDown() {
  if (document.querySelector(".list-item")) {
    document.querySelector(".player-footer").style.bottom = "20em";
    document.querySelector(".player-list-container").style.bottom = "-1em";
    document.querySelector(".list-item").focus();
  }
}

function listScrollUp() {
  if (document.querySelector(".list-item")) {
    document.querySelector(".player-footer").style.bottom = "7em";
    document.querySelector(".player-list-container").style.bottom = "-16em";
    document.querySelector("#favourite-button").focus();
  }
}

function downHandler(section) {
  if (section === "menu") {
    if (document.querySelector("#banner-image")) {
      document.querySelector("#banner-image").focus();
    } else if (document.querySelector("#r")) {
      document.querySelector("#r").focus();
    } else if (document.querySelector('ul[row="row-0"]')) {
      document.querySelector('ul[row="row-0"]').firstChild.focus();
    } else if (document.querySelector("#logout")) {
      document.querySelector("#logout").focus();
    }
  } else if (section === "banner") {
    if (document.querySelector('ul[row="row-0"]')) {
      document.querySelector('ul[row="row-0"]').firstChild.focus();
    }
  } else if (section === "home-list" || section === "favourite-list") {
    var down = document.activeElement.getAttribute("down");
    var row = document.activeElement.getAttribute("row");
    var h = document.activeElement.parentNode.parentNode.offsetHeight / 16;
    if (document.querySelector('ul[row="' + down + '"]')) {
      NavHelper.scrollVDynamic(row, h, ".group", "DOWN");
      document.querySelector('ul[row="' + down + '"]').firstChild.focus();
      document
        .querySelector("ul[row='" + down + "']")
        .parentNode.childNodes[0].scrollIntoView();
    }
  } else if (section === "alphabates") {
    if (document.querySelector("#four")) {
      document.querySelector("#four").focus();
    }
  } else if (section === "numbers") {
    if (document.querySelector('ul[section="searchlist"] li')) {
      document.querySelector('ul[section="searchlist"] li').focus();
    }
  } else if (section === "controls") {
    if (document.querySelector("#favourite-button")) {
      document.querySelector("#favourite-button").focus();
    }
  } else if (section === "favourite") {
    listScrollDown();
  }
}

function upHandler(section) {
  if (section === "home-list" || section === "favourite-list") {
    var up = document.activeElement.getAttribute("up");
    var row = document.activeElement.getAttribute("row");
    var h = document.activeElement.parentNode.parentNode.offsetHeight / 16;
    if (document.querySelector('ul[row="' + up + '"]') && up !== "row--1") {
      NavHelper.scrollVDynamic(row, h, ".group", "UP");
      document.querySelector('ul[row="' + up + '"]').firstChild.focus();
      document
        .querySelector("ul[row='" + up + "']")
        .parentNode.childNodes[0].scrollIntoView();
    } else if (document.querySelector("#banner-image")) {
      document.querySelector("#banner-image").focus();
      document.querySelector(".group").style.marginTop = "0em";
    } else if (document.querySelector(".menu-list")) {
      if (document.querySelector(".menu-list .active"))
        document.querySelector(".menu-list .active").focus();
      else document.querySelector(".menu-item").focus();
    }
  } else if (section === "banner") {
    if (document.querySelector(".menu-list")) {
      document.querySelector(".group").style.marginTop = "0em";
      if (document.querySelector(".menu-list .active"))
        document.querySelector(".menu-list .active").focus();
      else document.querySelector(".menu-item").focus();
    }
  } else if (section === "numbers") {
    if (document.querySelector("#r")) {
      document.querySelector("#r").focus();
    }
  } else if (section === "alphabates" || section === "logout") {
    if (document.querySelector(".menu-list")) {
      if (document.querySelector(".menu-list .active"))
        document.querySelector(".menu-list .active").focus();
      else document.querySelector(".menu-item").focus();
    }
  } else if (section === "searchlist") {
    if (document.querySelector("#four")) {
      document.querySelector("#four").focus();
    }
  } else if (section === "player-list") {
    listScrollUp();
  } else if (section === "favourite") {
    if (document.querySelector("#playpause")) {
      document.querySelector("#playpause").focus();
    }
  }
}
