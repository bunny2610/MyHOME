var Player = {};

var listener = {
    onbufferingstart: function (e) {
        Player.duration=webapis.avplay.getDuration();
        if(Player.playerCallback){
            Player.playerCallback('onbufferingstart',Player.duration);
        }
    },
    onbufferingprogress: function (percent) {
        if(Player.playerCallback){
            Player.playerCallback('onbufferingprogress',Player.duration);
        }
    },
    onbufferingcomplete: function (e) {
        Player.duration=webapis.avplay.getDuration();
        if(Player.playerCallback){
            Player.playerCallback('onbufferingcomplete',Player.duration);
        }
    },
    oncurrentplaytime: function (currentTime) {
        if(Player.playerCallback){
            Player.playerCallback('ontimeupdate',currentTime,Player.duration);
        }
    },
    onevent: function (eventType, eventData) {
        if(Player.playerCallback){
            switch(eventType){
                case 'PLAYER_MSG_RESOLUTION_CHANGED':
                case 'PLAYER_MSG_BITRATE_CHANGE':
                    Player.playerCallback(eventType,webapis.avplay.getDuration());
                    break;
            }
        }
    },
    ondrmevent: function (drmEvent, drmData) {
        if(Player.playerCallback){
            Player.playerCallback(drmEvent);
        }

    },
    onstreamcompleted: function (e) {
        try {
            if(Player.playerCallback){
                Player.playerCallback('onended');
            }
            webapis.avplay.stop();
        } catch (e) {

        }
    },
    onerror: function (eventType) {
        if(Player.playerCallback){
            Player.playerCallback(eventType);
        }
    }
};

Player.init = function (playerID, url,playerCallback) {
    Player.playerCallback=playerCallback;
    Player.url = url;
    try {
        webapis.avplay.open(url);
        setTimeout(function () {
            webapis.avplay.setDisplayRect(0, 0, 1920, 1080);
            webapis.avplay.setListener(listener);
            webapis.avplay.prepareAsync(function () {
               webapis.avplay.play();
            });
        }, 200);
    } catch (e) {}
};

Player.setDisplayArea = function (x, y, width, height) {
    try {
        webapis.avplay.setDisplayRect(x, y, width, height);
    }
    catch (e) {}
};

Player.play = function () {
    try {
        webapis.avplay.play();
        if (Player.playerCallback) {
            Player.playerCallback('onplay');
        }
    }
    catch (e) {}
};

Player.pause = function () {
    try {
        webapis.avplay.pause();
        if (Player.playerCallback) {
            Player.playerCallback('onpause');
        }
    }
    catch (e) {}
};

Player.rewind = function (time) {
    Player.seek(time);
};

Player.forward = function (time) {
    Player.seek(time);
};

Player.seek = function (time) {
    try {
        webapis.avplay.seekTo(time*1000);
    }
    catch (e) {}
};

Player.stop = function () {
    try {
        webapis.avplay.setListener(null);
        webapis.avplay.stop();
        webapis.avplay.close();
    } catch (e) {}
};

Player.suspend=function(){
    try {
        webapis.avplay.suspend();
    }
    catch (e) {}
};

Player.resume = function () {
    try {
        webapis.avplay.resume();
    }
    catch (e) {}
};

Player.destroy = function () {
    try {
        webapis.avplay.setListener(null);
        webapis.avplay.stop();
        webapis.avplay.close();
        Player.duration=0;
        Player.playerCallback=null;
        Player.url=null;
    } catch (e) {}
};

module.exports = Player;