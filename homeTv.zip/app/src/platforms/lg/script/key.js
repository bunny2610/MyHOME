(function () {
    var KEY = {};
    KEY.LEFT = 37;
    KEY.UP = 38;
    KEY.RIGHT = 39;
    KEY.DOWN = 40;
    KEY.ENTER = 13;
    KEY.BACK_WEB = 8;
    KEY.BACK = 461;
    KEY.KEY_BOARD_HIDE=65385;
    KEY.DONE=65376;
    KEY.FORWARD=417;
    KEY.REWIND=412;
    KEY.PAUSE=19;
    KEY.PLAY=415;
    KEY.SUBTITLE=460;
    KEY.STOP=413;

    module.exports = KEY;
})();
