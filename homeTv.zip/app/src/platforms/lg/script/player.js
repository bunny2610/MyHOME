var Player = function () {

    var that = this;
    var hls =null;
    this.init = function (playerID, url,playerCallback) {
        this.playerObj = document.getElementById(playerID);
        this.url = url;
        this.playerCallback=playerCallback;
        this.loadplayer();
    };

    this.loadplayer = function () {
        if(this.url.indexOf('.m3u8')!==-1) {
            hls = new window.Hls();
            hls.startLevel = 0;
            hls.loadSource(this.url);
            hls.attachMedia(this.playerObj);
            hls.on(window.Hls.Events.MANIFEST_PARSED, function () {
                that.playerObj.play();
            });
            hls.on(window.Hls.Events.ERROR, function (event, data) {
                if (that.playerCallback) {
                    that.playerCallback('networkError');
                }
            });
        }
        else{
            that.playerObj.src=this.url;
        }
        this.bindPlayerEvent();
    };

    this.bindPlayerEvent = function () {
        this.playerObj.addEventListener('loadedmetadata', this.onLoadedMetaData.bind(this));
        this.playerObj.addEventListener('loadeddata', this.onLoadedData.bind(this));
        this.playerObj.addEventListener('play', this.onPlay.bind(this));
        this.playerObj.addEventListener('pause', this.onPause.bind(this));
        this.playerObj.addEventListener('timeupdate', this.onTimeUpdate.bind(this));
        this.playerObj.addEventListener('waiting', this.onWaiting.bind(this));
        this.playerObj.addEventListener('seeking', this.onSeeking.bind(this));
        this.playerObj.addEventListener('seeked', this.onSeeked.bind(this));
        this.playerObj.addEventListener('playing', this.onPlaying.bind(this));
        this.playerObj.addEventListener('ended', this.onEnded.bind(this));
        this.playerObj.addEventListener('error', this.onPlaybackError.bind(this));
    };

    this.onLoadedMetaData = function () {
        if(this.playerCallback) {
            this.playerCallback('onloadedmetadata',this.playerObj.duration*1000);
        }
    };

    this.onLoadedData=function(){
        if(that.playerObj){
            that.playerObj.play();
        }
        if(this.playerCallback) {
            this.playerCallback('onloadeddata');
        } 
    }

    this.onPlay = function () {
        if(this.playerCallback) {
            this.playerCallback('onplay');
        }
    };

    this.onPause = function () {
        if(this.playerCallback) {
            this.playerCallback('onpause');
        }
    };

    this.onTimeUpdate = function () {
        if(this.playerCallback) {
            this.playerCallback('ontimeupdate', this.playerObj.currentTime*1000,this.playerObj.duration*1000);
        }
    };

    this.onWaiting = function () {
        if(this.playerCallback) {
            this.playerCallback('onwaiting');
        }
    };

    this.onSeeking = function () {
        if(this.playerCallback) {
            this.playerCallback('onseeking');
        }
    };

    this.onSeeked = function () {
        if(this.playerCallback) {
            this.playerCallback('onseeked');
        }
    };

    this.onPlaying = function () {
        if(this.playerCallback) {
            this.playerCallback('onplaying');
        }
    };

    this.onEnded = function () {
        if(this.playerCallback) {
            this.playerCallback('onended');
        }
    };

    this.onPlaybackError = function (e) {
        if(this.playerCallback) {
            this.playerCallback('onplaybackerror', e);
        }
    };

    this.setDisplayArea = function () {

    };

    // custom actions event

    this.play = function () {
        this.playerObj.play();
    };

    this.pause = function () {
        this.playerObj.pause();
    };

    this.rewind = function () {
        this.seek(this.playerObj.currentTime-10);
        this.play();
    };

    this.forward = function () {
        this.seek(this.playerObj.currentTime+10);
        this.play();
    };

    this.seek = function (time) {
        this.playerObj.currentTime = time;
    };

    this.stop = function () {
        try {
            this.playerObj.pause();
            this.playerObj.removeAttribute('src');
            this.playerObj.load();
        }
        catch (e) {}
    };

    this.destroy = function () {
        try {
            if(hls){
                hls.destroy();
                hls=null;
            }
            this.playerObj.pause();
            this.playerObj.removeAttribute('src');
            this.playerObj.load();
            this.url=null;
            this.playerCallback=null;
        }
        catch (e) {}
    };


};

module.exports = new Player();