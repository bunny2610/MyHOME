(function () {

    var CONFIG = require('./config');
    var generic = {};

    setTimeout(function () {
        generic.getDeviceId();
    }, 2000);

    window.Network = {
        connected: window.navigator.onLine
    };

    generic.exit = function (widgetAPI, event) {
        window.close();
    };

    generic.getDeviceId=function(){
        if(CONFIG.uid){
            return CONFIG.uid;
        }
        webOS.service.request("luna://com.webos.service.sm", {
            method: "deviceid/getIDs",
            parameters: {
                "idType": ["LGUDID"]
            },
            onSuccess: function (inResponse) {
                if (inResponse && inResponse.returnValue) {
                    var deviceList = inResponse.idList;
                    if (deviceList && deviceList.length > 0) {
                        var deviceData = deviceList[0];
                        if (deviceData && deviceData.idValue) {
                            CONFIG.uid = deviceData.idValue;
                            return CONFIG.uid;
                        } else {
                            return generic.generateUDID_OS2();
                        }
                    } else {
                        return generic.generateUDID_OS2();
                    }
                } else {
                    return generic.generateUDID_OS2();
                }
            },
            onFailure: function (inError) {
                console.log("Failed to get system ID information");
                console.log("[" + inError.errorCode + "]: " + inError.errorText);
                return generic.generateUDID_OS2();
            }
        });
    };

    generic.generateUDID_OS2 = function () {
        try {
            var d = new Date().getTime();
            CONFIG.uid = webOS.device.platformVersion + "-" + d;
            return CONFIG.uid;
        }
        catch (e) {}
    };

    generic.getDeviceModel=function(){
        return "43UJ949T-TA";
        // webOS.service.request("luna://com.webos.service.tv.systemproperty", {
        //     method: "getSystemInfo",
        //     parameters: {
        //         "keys": ["modelName"]
        //     },
        //     onComplete: function (inResponse) {
        //         var isSucceeded = inResponse.returnValue;
        //         if(isSucceeded && isSucceeded['modelName']){
        //             return isSucceeded['modelName'];
        //         }else{
        //             return "43UJ632T-TA";
        //         }
        //     }
        // });
    };

    generic.getDeviceOS = function () {
        return "WebOS";
    };

    generic.getDevicePlatform = function () {
        return "LG";
    };

    generic.getAppVersion = function () {
        const path = window.webOS.fetchAppRootPath();
        if (path.length !== 0) {
        window.webOS.fetchAppInfo(function(info){
            if (info) {
            return info.version;
            } else {
                return CONFIG.APP_VERSION;
            }
        }, path + 'appinfo.json');
        } else {
            return CONFIG.APP_VERSION;
        }
        return CONFIG.APP_VERSION;
    };

    generic.getDevicePlatformVersion = function () {
        if(CONFIG.device_platform_version){
            return CONFIG.device_platform_version;
        }
        else {
            try {
                CONFIG.device_platform_version='3.0.0';
                return CONFIG.device_platform_version;
                // return webOS.deviceInfo(function (device) {
                //     var sdkVersion = device.sdkVersion;
                //     CONFIG.device_platform_version=sdkVersion;
                //     return sdkVersion;
                // });
            }
            catch (err) {
                return "";
            }
        }
    };

    generic.getNetworkStatus = function () {
        return window.navigator.onLine;
    };


    module.exports = generic;
})();
