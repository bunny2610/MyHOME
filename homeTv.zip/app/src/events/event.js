(function () {
  var KEY = require("../utils/key.js");

  function bindEvent(ele, events) {
    var element = document.querySelector(ele);
    if (element) {
      for (var i = 0; i < events.length; i++) {
        if (events[i].eventType == "focus" || events[i].eventType == "blur") {
          element.addEventListener(
            events[i].eventType,
            events[i].handler,
            true
          );
        } else {
          element.addEventListener(
            events[i].eventType,
            events[i].handler,
            false
          );
        }
      }
    }
  }

  function unbindEvent(events) {
    var element = document.querySelector(container);
    for (var i = 0; i < events.length; i++) {
      element.removeEventListener(events[i].eventType, events[i].handler);
    }
  }

  this.init = function (obj) {
    var objdata = obj;
    setTimeout(function () {
      if (
        typeof objdata !== "undefined" &&
        objdata &&
        objdata.constructor === Array
      ) {
        for (var j = 0; j < objdata.length; j++) {
          bindEvent(objdata[j].element, objdata[j].events);
        }
      } else if (
        typeof objdata !== "undefined" &&
        objdata &&
        objdata.constructor === Object
      ) {
        bindEvent(objdata.element, objdata.events);
      }
    }, 100);
  };

  module.exports = this;
})();
