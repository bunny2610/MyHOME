(function () {
  var KEY = require("../utils/key.js");
  var CONFIG = require("../utils/config");

  var nav = {};

  nav.navigation = function (e, direction, element) {
    var key = e.keyCode ? e.keyCode : e.which;
    switch (key) {
      case KEY.LEFT:
        if (direction === CONFIG.NAV_DIRECTION.HORIZONTAL) {
          nav.prev(e, element);
        } else if (direction === CONFIG.NAV_DIRECTION.VERTICLE) {
          if (element) {
            nav.random(e, element);
          } else if (
            e.target.parentNode &&
            e.target.parentNode.getAttribute("left")
          ) {
            var left = e.target.parentNode.getAttribute("left");
            if (document.querySelector("#" + left).children) {
              if (
                document.querySelector("#" + left).children[0].tagName === "svg"
              )
                document.querySelector("#" + left).focus();
              else document.querySelector("#" + left).children[0].focus();
            }
          }
        } else if (direction === CONFIG.NAV_DIRECTION.RANDOM) {
          nav.random(e, "left");
        }
        break;
      case KEY.RIGHT:
        if (direction === CONFIG.NAV_DIRECTION.HORIZONTAL) {
          nav.next(e, element);
        } else if (direction === CONFIG.NAV_DIRECTION.VERTICLE) {
          if (element) {
            nav.random(e, element);
          } else if (
            e.target.parentNode &&
            e.target.parentNode.getAttribute("right")
          ) {
            var name = e.target.parentNode.getAttribute("right");
            if (document.querySelector("#" + name).children.length > 0) {
              document.querySelector("#" + name).children[0].focus();
            } else if (document.querySelector("#" + name)) {
              document.querySelector("#" + name).focus();
            }
          }
        } else if (direction === CONFIG.NAV_DIRECTION.RANDOM) {
          nav.random(e, "right");
        }
        break;
      case KEY.UP:
        if (direction === CONFIG.NAV_DIRECTION.HORIZONTAL) {
          nav.random(e, "up");
        } else if (direction === CONFIG.NAV_DIRECTION.VERTICLE) {
          nav.prev(e, "up");
        } else if (direction === CONFIG.NAV_DIRECTION.RANDOM) {
          nav.random(e, "up");
        }
        break;
      case KEY.DOWN:
        if (direction === CONFIG.NAV_DIRECTION.HORIZONTAL) {
          nav.random(e, "down");
        } else if (direction === CONFIG.NAV_DIRECTION.VERTICLE) {
          nav.next(e, "down");
        } else if (direction === CONFIG.NAV_DIRECTION.RANDOM) {
          nav.random(e, "down");
        }
        break;
    }
  };

  nav.prev = function (e, key) {
    if (
      e.target.previousElementSibling &&
      e.target.previousElementSibling.style.display !== "none"
    ) {
      e.target.previousElementSibling.focus();
    } else if (key) {
      nav.random(e, key);
    } else {
      nav.random(e, "left");
    }
  };

  nav.next = function (e, key) {
    if (
      e.target.nextElementSibling &&
      e.target.nextElementSibling.style.display !== "none"
    ) {
      e.target.nextElementSibling.focus();
    } else if (key) {
      nav.random(e, key);
    } else {
      nav.random(e, "right");
    }
  };

  nav.random = function (e, key) {
    var elekey = e.target.getAttribute(key);
    if (!elekey) {
      elekey = e.target.parentNode.getAttribute(key);
    }
    var element = document.querySelector("#" + elekey);
    if (element) {
      element.focus();
    } else if (document.querySelector("#" + key)) {
      document.querySelector("#" + key).focus();
    }
  };

  nav.setActive = function (e, width, scrollindex, isScrollable) {
    var index = e.target.getAttribute("index");
    var className = e.target.getAttribute("class");
    var scrollclass = e.target.getAttribute("scrollclass");
    var lastIndex = className.indexOf("active");
    lastIndex = lastIndex < 0 ? className.length : lastIndex;
    className = className.slice(0, lastIndex);
    className = className.trim();
    var elements = e.target.parentNode.querySelectorAll(".active");
    if (elements && elements.length) {
      elements[0].setAttribute("class", className);
    }
    e.target.setAttribute("class", className + " active");
    if (isScrollable) {
      nav.scrollH(parseInt(index), width, scrollclass, scrollindex);
    }
  };

  nav.scrollH = function (index, width, element, scrollindex) {
    var placeToMove = 0;
    if (!scrollindex) {
      scrollindex = 3;
    }
    if (index < scrollindex) {
      placeToMove = 0;
    } else {
      placeToMove = index - scrollindex;
    }
    var current = document.querySelector('[scrollclass="' + element + '"]');
    if (current) {
      current.style.marginLeft = "-" + width * placeToMove + "em";
    }
  };

  nav.scrollVWithoutAnimation = function (index, height, parent, scrollindex) {
    var placeToMove = 0;
    if (!scrollindex) {
      scrollindex = 0;
    }
    if (index < scrollindex) {
      placeToMove = 0;
    } else {
      placeToMove = index - scrollindex;
    }
    var current = document.querySelector(parent);
    if (current) {
      // current.style.marginTop = ('-' + (height * placeToMove) + 'em');
    }
  };

  nav.scrollVDynamic = function (index, height, parent, direction) {
    var current = document.querySelector(parent);
    if (current) {
      var margin = current.style.marginTop;
      margin = margin.replace("-", "").replace("em", "");
      if (margin) {
        margin = parseInt(margin, 10);
      }
      if (direction === "DOWN") {
        // current.style.marginTop = ('-' + (Number(margin) + Number(height)) + 'em');
      } else if (direction === "UP") {
        // current.style.marginTop = ('-' + (Number(margin) - Number(height)) + 'em');
      }
    }
  };

  module.exports = nav;
})();
