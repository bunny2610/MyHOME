var CONFIG = require("../utils/config");
var axios = require("../lib/axios");
var Generic = require("../utils/generic");

var apiHelper = {};

apiHelper.getDeviceDetails = function () {
  var url = CONFIG.DEVICE_DETAILS_URL;
  return axios.post(url, {
    api_key: "4bd4430d-eed7-439a-9f23-f0d065c86ab2",
    uuid: "e31ad55a-ab72-4e11-b9c1-8eb840683ace",
    device_id: "BBB144AC-DEFC-4EBC-8C79-D4C66D04391F",
    device_name: "Bunny",
    device_model: "Vostro",
    device_version: "15 3510",
    device_token: "qwertyuiop",
    rano: 2500,
    ip_address: "192.168.100.1",
    continent: "Europe",
    continentCode: "EU",
    country: "United Kingdom",
    countryCode: "GB",
    city: "Rathfriland",
    zip: "BT34",
    lat: "54.25",
    lon: "-6.16667",
    account_availability: true,
    email: "kanwar.gaurav22@gmail.com",
    regionName: "Northern",
    region: "NIR",
    mobile: true,
    district: "NA",
    proxy: "NA",
  });
};

apiHelper.verifyOtp = function () {
  var url = CONFIG.VERIFY_OTP_URL;
  return axios.post(url, {
    api_key: "4bd4430d-eed7-439a-9f23-f0d065c86ab2",
    otp: CONFIG.OTP,
  });
};

apiHelper.getChannelList = function () {
  var url = CONFIG.CHANNEL_LIST_URL;
  var bodyData = {
    uuid: "e31ad55a-ab72-4e11-b9c1-8eb840683ace",
    device_id: "BBB144AC-DEFC-4EBC-8C79-D4C66D04391F",
    api_key: "4bd4430d-eed7-439a-9f23-f0d065c86ab2",
    account_availability: true,
    email: "kanwar.gaurav22@gmail.com",
  };

  // console.log(bodyData);

  var headers = {
    // 'Content-Type': 'application/json',
  };
  var userDetails = localStorage.getItem("userDetails");
  // console.log(JSON.stringify(userDetails));
  if (userDetails) {
    userDetails = JSON.parse(userDetails);
    bodyData.email = bodyData.email || userDetails.email;
    bodyData.account_availability = "true";
    headers["Authorization"] = "Bearer " + userDetails.token;
  } else {
    bodyData.account_availability = "FALSE";
  }
  return axios.post(url, bodyData, { headers: headers });
};
/ GET_PACKAGE_List_api /;
apiHelper.getPakagelist = function () {
  var url = CONFIG.PACKAGE_LIST_URL;
  var bodyData = {
    api_key: "4bd4430d-eed7-439a-9f23-f0d065c86ab2",
    uuid: "e31ad55a-ab72-4e11-b9c1-8eb840683ace",
    device_id: "325C2535-686F-4190-AFB0-1A5C1247601",
    account_availability: true,
    email: "kanwar.gaurav22@gmail.com",
  };

  // var headers = {
  //   'Content-Type': 'application/json',
  // }
  var userDetails = localStorage.getItem("userDetails");
  // console.log(JSON.stringify(userDetails));
  if (userDetails) {
    userDetails = JSON.parse(userDetails);
    bodyData.email = userDetails.email;
    bodyData.account_availability = "TRUE";
    // headers.Authorization= userDetails.token;
  } else {
    bodyData.account_availability = "FALSE";
  }
  return axios.post(url, bodyData);
};

/ SET_PACKAGE_List_api /;

apiHelper.setPakage = function () {
  var url = CONFIG.SET_PACKAGE_URL;
  var packageId = localStorage.getItem("package_name");
  var bodyData = {
    uuid: "e31ad55a-ab72-4e11-b9c1-8eb840683ace",
    device_id: "BBB144AC-DEFC-4EBC-8C79-D4C66D04391F",
    api_key: "4bd4430d-eed7-439a-9f23-f0d065c86ab2",
    package_id: packageId,
  };
  // var headers = {
  //   'Content-Type': 'application/json',
  // }
  var userDetails = localStorage.getItem("userDetails");
  // console.log(JSON.stringify(userDetails));
  if (userDetails) {
    userDetails = JSON.parse(userDetails);
    bodyData.email = userDetails.email;
    bodyData.account_availability = "TRUE";
    // headers.Authorization= userDetails.token;
  } else {
    bodyData.account_availability = "FALSE";
  }
  return axios.post(url, bodyData);
};

apiHelper.generateOtp = function () {
  var url = CONFIG.GENERATE_OTP_URL;
  return axios.post(url, {
    // serial_no: Generic.getDeviceId(),
    // platform: Generic.getDevicePlatform(),
    api_key: "4bd4430d-eed7-439a-9f23-f0d065c86ab2",
    uuid: "e31ad55a-ab72-4e11-b9c1-8eb840683ace",
    device_id: "BBB144AC-DEFC-4EBC-8C79-D4C66D04391F",
  });
};

apiHelper.getChannelData = function (data) {
  return new Promise((resolve, reject) => {
    resolve({ data });
  });

  // var url = CONFIG.CHANNEL_DATA_URL;
  // var bodyData = {
  //   theme: "Dark",
  //   channel_id: data.channel_id || data.item_id,
  //   category_id: data.catid,
  //   platform: Generic.getDevicePlatform(),
  // };
  // var userDetails = localStorage.getItem("userDetails");
  // if (userDetails) {
  //   userDetails = JSON.parse(userDetails);
  //   bodyData.email = userDetails.email;
  //   bodyData.account_availability = "TRUE";
  // } else {
  //   bodyData.account_availability = "FALSE";
  // }
  // return axios.post(url, bodyData);
};

apiHelper.addRemoveFavorites = function (data) {
  var url = CONFIG.ADD_REMOVE_FAVORITES;
  return axios.post(url, {
    channel_id: data.channel_id,
    email: data.email,
  });
};

apiHelper.getFavoritesList = function (data) {
  var url = CONFIG.GET_FAVORITES_LIST;
  return axios.post(url, {
    theme: "Dark",
    account_availability: data.account_availability,
    email: data.email,
  });
};

apiHelper.getRecommendedList = function (data) {
  var url = CONFIG.GET_RECOMMENDED_LIST;
  return axios.post(url, {
    theme: "Dark",
    account_availability: data.account_availability,
    email: data.email,
  });
};

apiHelper.getPackage = function () {
  var url = "https://lgt01mhtv.anystream.uk/lg_tv_v1/index.php/get_packages";
  return axios.post(
    url,
    {
      api_key: "4bd4430d-eed7-439a-9f23-f0d065c86ab2",
      uuid: "e31ad55a-ab72-4e11-b9c1-8eb840683ace",
      device_id: "325C2535-686F-4190-AFB0-1A5C1247601",
      account_availability: true,
      email: "kanwar.gaurav22@gmail.com",
    },
    {
      headers: { "content-type": "application/json" },
    }
  );
};

apiHelper.getStoreUserDetails = function () {
  return axios.post(
    "https://lgt01mhtv.anystream.uk/lg_tv_v1/index.php/store_user_detail",
    {
      api_key: "4bd4430d-eed7-439a-9f23-f0d065c86ab2",
      uuid: "e31ad55a-ab72-4e11-b9c1-8eb840683ace",
      device_id: "BBB144AC-DEFC-4EBC-8C79-D4C66D04391F",
      device_name: "Bunny",
      device_model: "Vostro",
      device_version: "15 3510",
      device_token: "qwertyuiop",
      rano: 2500,
      ip_address: "192.168.100.1",
      continent: "Europe",
      continentCode: "EU",
      country: "United Kingdom",
      countryCode: "GB",
      city: "Rathfriland",
      zip: "BT34",
      lat: "54.25",
      lon: "-6.16667",
      account_availability: true,
      email: "kanwar.gaurav22@gmail.com",
      regionName: "Northern",
      region: "NIR",
      mobile: true,
      district: "NA",
      proxy: "NA",
    },
    {
      headers: {
        accept: "application/json",
        "Content-Type": "application/json",
      },
    }
  );
};

module.exports = apiHelper;
