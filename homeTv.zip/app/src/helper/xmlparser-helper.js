(function () {
    var xml2json=require('../lib/xml2json');
    function parseXml(xml) {
        var dom = null;
        if (window.DOMParser) {
            try {
                dom = (new DOMParser()).parseFromString(xml, "text/xml");
            } catch (e) {
                dom = null;
            }
        } else if (window.ActiveXObject) {z
            try {
                dom = new ActiveXObject('Microsoft.XMLDOM');
                dom.async = false;
                if (!dom.loadXML(xml)) // parse error ..

                    console.log(dom.parseError.reason + dom.parseError.srcText);
            } catch (e) {
                dom = null;
            }
        } else {
            throw "cannot parse xml string!";
        }
        return dom;
    }

    var xmlParser = function (xmldata) {
        try {
            var dom = parseXml(xmldata);
            var stringData = xml2json(dom, '');
            var json = JSON.parse(stringData);
            return json;
        } catch (err) {
            console.log(err);
        }
    };

    module.exports = xmlParser;
})();

