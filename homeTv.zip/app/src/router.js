const { getPakagelist } = require("./helper/api-helper");
var CONFIG = require("./utils/config");

(function () {
  var Navigo = require("./lib/navigo");
  var Loader = require("./controllers/popup/loader");
  var ApiHelper = require("./helper/api-helper");

  var HomeCtrl,
    LanguageCtrl,
    PlayerCtrl,
    SettingCtrl,
    SearchCtrl,
    epgCtrl,
    FavouritesCtrl,
    loginCtrl;

  var root = null;
  var useHash = true;
  var hash = "#";
  var router = new Navigo(root, useHash, hash);
  var Routers = {};

  Routers.start = function () {
    Routers.init();
  };

  Routers.init = function () {
    router
      .on({
        player: {
          as: "player",
          uses: playerRouteHandler,
          hooks: { before: playerBeforeHook },
        },
        favourites: {
          as: "favourites",
          uses: favouritesHandler,
          hooks: { before: favouritesBeforeHook },
        },
        settings: {
          as: "settings",
          uses: settingsHandler,
          hooks: { before: settingsBeforeHook },
        },
        search: {
          as: "search",
          uses: searchHandler,
          hooks: { before: searchBeforeHook },
        },
        login: {
          as: "login",
          uses: loginHandler,
          hooks: { before: loginBeforeHook },
        },
        live: {
          as: "live",
          uses: liveHandler,
          hooks: { before: liveBeforeHook },
        },
        epg: {
          as: "epg",
          uses: epgHandler,
          hooks: { before: epgBeforeHook },
        },
        // home: {
        //   as: "home",
        //   uses: homeRootHandler,
        //   hooks: { before: homeBeforeHook },
        // },
        "/": {
          as: "/",
          uses: baseRootHandler,
          hooks: { before: baseBeforeHook },
        },
      })
      .resolve();
  };

  function epgBeforeHook(callback) {
    callback(true);
  }

  function epgHandler() {
    destroyAssets();
    epgCtrl = require("./controllers/epgCtrl");
    epgCtrl.init();
  }

  function playerBeforeHook(callback) {
    callback(true);
  }

  function playerRouteHandler(params) {
    destroyAssets();
    var menuContainer = document.querySelector(".menu-container");
    if (menuContainer) menuContainer.innerHTML = "";
    PlayerCtrl = require("./controllers/playerCtrl");
    PlayerCtrl.init();
  }

  function baseBeforeHook(callback) {
    callback(true);
  }

  function baseRootHandler() {
    destroyAssets();
    Loader.show();
    if (!localStorage.getItem("package_name")) {
      LanguageCtrl = require("./controllers/languageCtrl");
      LanguageCtrl.init().then(
        function () {},
        function () {}
      );
    } else {
      ApiHelper.getChannelList().then(
        function (response) {
          CONFIG.appBackgroundData = response.data;
          loadLiveController();
        },
        function (error) {
          loadLiveController();
        }
      );
    }
  }

  function liveBeforeHook(callback) {
    callback(true);
  }
  function liveHandler() {
    destroyAssets();
    loadLiveController();
  }

  function loadLiveController() {
    // Loader.show();
    ApiHelper.getDeviceDetails().then(
      function (resp) {
        if (resp.status == 200) {
          localStorage.setItem("userDetails", JSON.stringify(resp.data));
        }
        HomeCtrl = require("./controllers/homeCtrl");
        HomeCtrl.init().then(
          function () {},
          function () {}
        );
      },
      function (err) {}
    );
  }

  // function liveBeforeHook(callback) {
  //   callback(true);
  // }

  // function liveHandler() {
  //   destroyAssets();
  //   Loader.show();
  //   HomeCtrl = require("./controllers/homeCtrl");
  //   HomeCtrl.init().then(
  //     function () {},
  //     function () {}
  //   );
  // }

  function favouritesBeforeHook(callback) {
    callback(true);
  }

  function favouritesHandler() {
    destroyAssets();
    FavouritesCtrl = require("./controllers/favouritesCtrl");
    FavouritesCtrl.init();
  }

  function settingsBeforeHook(callback) {
    callback(true);
  }

  function settingsHandler() {
    destroyAssets();
    SettingCtrl = require("./controllers/settingCtrl");
    SettingCtrl.init();
  }

  function searchBeforeHook(callback) {
    callback(true);
  }

  function searchHandler() {
    destroyAssets();
    SearchCtrl = require("./controllers/searchCtrl");
    SearchCtrl.init();
  }

  function loginBeforeHook(callback) {
    callback(true);
  }

  function loginHandler() {
    destroyAssets();
    loginCtrl = require("./controllers/loginCtrl");
    loginCtrl.init();
  }

  window.changeUrl = function (url, params, query) {
    var URL = "";
    if (params && query) {
      URL = router.generate(url, params, query);
      URL = URL + "?" + query.title;
      router.navigate(URL, true);
    } else if (params) {
      URL = router.generate(url, params);
      router.navigate(URL, true);
    } else {
      router.navigate(url, true);
    }
  };

  function destroyAssets() {
    if (HomeCtrl) HomeCtrl.destroy();
    if (loginCtrl) loginCtrl.destroy();
    if (SearchCtrl) SearchCtrl.destroy();
    if (PlayerCtrl) PlayerCtrl.destroy();
    if (SettingCtrl) SettingCtrl.destroy();
    if (FavouritesCtrl) FavouritesCtrl.destroy();
    if (epgCtrl) epgCtrl.destroy();
  }

  module.exports = Routers;
})();
