var CONFIG = {};

CONFIG.BASE_URL = "https://lgt01mhtv.anystream.uk/lg_tv_v1/index.php/";
CONFIG.DEVICE_DETAILS_URL = CONFIG.BASE_URL + "store_user_detail";
CONFIG.GENERATE_OTP_URL = CONFIG.BASE_URL + "generate_otp";
CONFIG.VERIFY_OTP_URL = CONFIG.BASE_URL + "verify";
CONFIG.CHANNEL_LIST_URL = CONFIG.BASE_URL + "channel_list";
CONFIG.PACKAGE_LIST_URL = CONFIG.BASE_URL + "get_packages";
CONFIG.SET_PACKAGE_URL = CONFIG.BASE_URL + "set_package";
CONFIG.CHANNEL_DATA_URL = CONFIG.BASE_URL + "live_channel_details";
CONFIG.ADD_REMOVE_FAVORITES = CONFIG.BASE_URL + "add_remove_favorites";
CONFIG.GET_FAVORITES_LIST = CONFIG.BASE_URL + "favorite_channel_list";
CONFIG.GET_RECOMMENDED_LIST = CONFIG.BASE_URL + "favorite_channel_list";

CONFIG.NAV_DIRECTION = {
  VERTICLE: 1,
  HORIZONTAL: 2,
  RANDOM: 3,
};

CONFIG.MESSAGE = {
  NETWORK: "Please check your network connection.",
};

CONFIG.POPUP_TYPE = {
  EXIT: "EXIT",
  NETWORK: "NETWORK",
  LOGOUT: "LOGOUT",
  BACK_TO_TOP: "BACK_TO_TOP",
};

CONFIG.APP_VERSION = "1.0.2";

module.exports = CONFIG;
