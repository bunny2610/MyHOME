var express = require("express");
var bodyParser = require("body-parser");
var app = express();
var path = require("path");

var allowCrossDomain = function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET,PUT,POST,DELETE,OPTIONS");
    res.header(
        "Access-Control-Allow-Headers",
        "Content-Type, Authorization, Content-Length, X-Requested-With"
    );
    if ("OPTIONS" === req.method) {
        res.send(200);
    } else {
        next();
    }
};

app.use(express.static(path.join(__dirname, "/app/build/")));
app.use(allowCrossDomain);
app.use(bodyParser.json());

app.set("port", process.env.PORT || 4000);

app.get("*", function (req, res) {
    console.log(__dirname);
    res.sendFile(path.join(__dirname + "/index.html"));
});

app.listen(app.get("port"), function () {
    console.log("Express server listening on port " + app.get("port"));
});
