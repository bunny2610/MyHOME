/**
 * Created by rajnishkumar on 06/06/17.
 */

var gulp = require("gulp");
var source = require("vinyl-source-stream");
var browserify = require("browserify");
var uglify = require("gulp-uglify");
var buffer = require("vinyl-buffer");
var rename = require("gulp-rename");
var stringify = require("stringify");
const sass = require("gulp-sass")(require("sass"));
var uglifycss = require("gulp-uglifycss");
var concat = require("gulp-concat");
var watch = require("gulp-watch");
var nodemon = require("gulp-nodemon");
var imagemin = require("gulp-imagemin");
var runSequence = require("run-sequence");
var rimraf = require("gulp-rimraf");
var path = require("path");
var inject = require("gulp-inject");
var insert = require("gulp-insert");
var argv = require("yargs").argv;
var browserSync = require("browser-sync").create();

var platform = argv && argv.platform ? argv.platform : "web";
var src = {
  script: "./app/src/app.js",
  image: ["./app/src/images/*.{jpg,png,gif,svg,webp}"],
  video: ["./app/src/*.mp4"],
  font: ["./app/src/fonts/*.{eot,otf,svg,ttf,woff,TTF}"],
  scss: ["./app/src/scss/base.scss"],
  platform: [
    "app/src/platforms/" + platform + "/*.*",
    "app/src/platforms/" + platform + "/.*",
    "app/src/platforms/" + platform + "/.*/.*",
    "app/src/platforms/" + platform + "/*.*/*.*",
  ],
  platformscript: "app/src/platforms/" + platform + "/script/*.js",
  vendorscriptCopy: "app/src/vendor/*.*",
};
var dist = {
  script: "./app/build/js",
  image: "./app/build/images",
  video: "./app/build/",
  font: "./app/build/fonts",
  css: "./app/build/css",
};

function bundle(bundler) {
  bundler
    .bundle()
    .pipe(source(src.script))
    .pipe(buffer())
    .pipe(rename("app.min.js"))
    .pipe(insert.prepend("var PLATFORM='" + platform + "';"))
    .pipe(uglify())
    .pipe(gulp.dest(dist.script));
}

gulp.task("scss", function () {
  return gulp
    .src(src.scss)
    .pipe(sass().on("error", sass.logError))
    .pipe(concat("app.min.css"))
    .pipe(
      uglifycss({
        maxLineLen: 80,
        uglyComments: true,
      })
    )
    .pipe(gulp.dest(dist.css))
    .pipe(browserSync.reload({ stream: true }));
});

gulp.task("script", function () {
  var bundler = browserify(src.script).transform(stringify, {
    appliesTo: { includeExtensions: [".dot", ".html"] },
  });
  bundle(bundler);
});

gulp.task("font", function () {
  return gulp.src(src.font).pipe(gulp.dest(dist.font));
});
gulp.task("image", function () {
  // return gulp.src(src.image).pipe(imagemin()).pipe(gulp.dest(dist.image));
  return gulp.src(src.image).pipe(gulp.dest(dist.image));

});

gulp.task("video", function () {
  return gulp.src(src.video).pipe(gulp.dest(dist.video));
});

gulp.task("platscriptCopy", function () {
  return gulp.src(src.platformscript).pipe(gulp.dest("./app/src/utils/"));
});
gulp.task("vendorscriptCopy", function () {
  return gulp.src(src.vendorscriptCopy).pipe(gulp.dest("./app/build/js/"));
});

gulp.task("platformCopy", function () {
  return gulp.src(src.platform).pipe(gulp.dest("./app/build/"));
});

gulp.task("watch", function () {
  watch(
    [
      "app/src/app.js",
      "app/src/router.js",
      "app/src/*",
      "app/src/*/*",
      "app/src/*/*/*",
      "app/src/scss/*",
    ],
    function (events, done) {
      gulp.start("script");
      gulp.start("scss");
    }
  );
});

gulp.task("clean", function (cb) {
  return gulp.src([path.join("app/build/")], { read: false }).pipe(rimraf());
});

gulp.task("injector", function () {
  return gulp
    .src("./app/src/index.html")
    .pipe(performChange())
    .pipe(gulp.dest("./app/build/"));
});

function performChange() {
  var myConfig = require("./app/src/config.json");
  var envConfig = myConfig[platform];
  envConfig = envConfig.join("\n");

  function transform(file, cb) {
    var contents = file.contents.toString("utf8");
    contents = contents.replace(
      /<!-- platform -->([\s\S]*?)<!-- platform end -->/gim,
      "<!-- platform -->\n" + envConfig + "\n<!-- platform end -->"
    );
    file.contents = new Buffer(contents, "utf8");
    file.contents = new Buffer(String(file.contents));
    cb(null, file);
  }

  return require("event-stream").map(transform);
}

gulp.task("build", function (callback) {
  runSequence(
    "clean",
    "vendorscriptCopy",
    "platscriptCopy",
    "scss",
    "script",
    "font",
    "image",
    "video",
    "injector",
    "platformCopy",
    callback
  );
});

gulp.task("browser-sync", ["server"], function () {
  browserSync.init({
    proxy: "localhost:4000",
    port: 3000,
    notify: true,
  });
});
gulp.task("server", function (cb) {
  var called = false;
  return nodemon({
    script: "server.js",
    ignore: ["var/", "gulpfile.js", "node_modules/"],
    watch: [],
    stdout: false,
    readable: false,
  })
    .on("start", function () {
      if (!called) {
        called = true;
        cb();
      }
    })
    .on("restart", function () {
      setTimeout(function () {
        browserSync.reload({ stream: false });
      }, 1000);
    });
});

gulp.task("default", ["build", "watch"], function () {
  console.log("task completed");
  gulp.start("browser-sync");
});
